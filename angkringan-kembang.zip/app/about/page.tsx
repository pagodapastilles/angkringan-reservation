import Image from "next/image"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default function AboutPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-12">
        <div className="container">
          <h1 className="text-3xl font-bold mb-8">Tentang Kami</h1>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-2xl font-semibold mb-4">Sejarah Angkringan Kembang</h2>
              <p className="mb-4">
                Angkringan Kembang didirikan pada tahun 2017 oleh Pak Agus, seorang pecinta kuliner tradisional
                Semarang. Angkringan Kembang telah berkembang
                menjadi tempat kuliner yang dikenal dengan cita rasa autentik dan pelayanan yang ramah.
              </p>
              <p>
                Nama "Kembang" diambil dari filosofi bunga yang selalu mekar dan memberikan keindahan. Kami berharap
                Angkringan Kembang dapat terus berkembang dan memberikan pengalaman kuliner yang menyenangkan bagi semua
                pelanggan kami.
              </p>
            </div>
            <div className="relative h-[400px] rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=800&width=600&text=Sejarah"
                alt="Sejarah Angkringan Kembang"
                fill
                className="object-cover"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
            <div className="relative h-[400px] rounded-lg overflow-hidden md:order-1 order-2">
              <Image
                src="/placeholder.svg?height=800&width=600&text=Visi%20Misi"
                alt="Visi dan Misi Angkringan Kembang"
                fill
                className="object-cover"
              />
            </div>
            <div className="md:order-2 order-1">
              <h2 className="text-2xl font-semibold mb-4">Visi dan Misi</h2>
              <div className="mb-6">
                <h3 className="text-xl font-medium mb-2">Visi</h3>
                <p>
                  Menjadi tempat kuliner tradisional terbaik yang mengedepankan kualitas, keaslian cita rasa, dan
                  pelayanan yang ramah.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-medium mb-2">Misi</h3>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Menyajikan makanan dan minuman tradisional dengan kualitas terbaik</li>
                  <li>Melestarikan resep-resep tradisional dengan sentuhan modern</li>
                  <li>Memberikan pelayanan yang ramah dan profesional</li>
                  <li>Menciptakan suasana yang nyaman dan bersahabat</li>
                  <li>Berkontribusi positif bagi masyarakat sekitar</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="text-center mb-16">
            <h2 className="text-2xl font-semibold mb-8">Tim Kami</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { name: "Pak Budi", role: "Pendiri & CEO" },
                { name: "Bu Siti", role: "Head Chef" },
                { name: "Mas Anto", role: "Manager Operasional" },
              ].map((person, index) => (
                <div key={index} className="text-center">
                  <div className="relative w-48 h-48 mx-auto rounded-full overflow-hidden mb-4">
                    <Image
                      src={`/placeholder.svg?height=200&width=200&text=${encodeURIComponent(person.name)}`}
                      alt={person.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <h3 className="text-xl font-semibold">{person.name}</h3>
                  <p className="text-muted-foreground">{person.role}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

