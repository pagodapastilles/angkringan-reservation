import { NextResponse } from "next/server"
import { setupDatabase } from "@/lib/db-schema"
import { seedDatabase } from "@/lib/seed-data"

export async function GET() {
  try {
    // Setup database schema
    await setupDatabase()

    // Seed database with initial data
    await seedDatabase()

    return NextResponse.json({
      success: true,
      message: "Database setup and seeding completed successfully",
    })
  } catch (error) {
    console.error("Error setting up database:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to setup database",
      },
      { status: 500 },
    )
  }
}

