import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Phone, Mail, Clock } from "lucide-react"

export default function ContactPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-12">
        <div className="container">
          <h1 className="text-3xl font-bold mb-8">Hubungi Kami</h1>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
            <div>
              <h2 className="text-2xl font-semibold mb-6">Kirim Pesan</h2>
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-1">
                      Nama
                    </label>
                    <Input id="name" placeholder="Nama Anda" />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-1">
                      Email
                    </label>
                    <Input id="email" type="email" placeholder="email@example.com" />
                  </div>
                </div>
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium mb-1">
                    Subjek
                  </label>
                  <Input id="subject" placeholder="Subjek pesan Anda" />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium mb-1">
                    Pesan
                  </label>
                  <Textarea id="message" placeholder="Tulis pesan Anda di sini..." rows={6} />
                </div>
                <Button type="submit" className="w-full md:w-auto">
                  Kirim Pesan
                </Button>
              </form>
            </div>

            <div>
              <h2 className="text-2xl font-semibold mb-6">Informasi Kontak</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center text-lg">
                      <MapPin className="mr-2 h-5 w-5" /> Alamat
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">Jl. Kembang Indah No. 123</p>
                    <p className="text-sm">Yogyakarta, Indonesia</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center text-lg">
                      <Phone className="mr-2 h-5 w-5" /> Telepon
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">(0274) 123456</p>
                    <p className="text-sm">0812-3456-7890</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center text-lg">
                      <Mail className="mr-2 h-5 w-5" /> Email
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">info@angkringankembang.com</p>
                    <p className="text-sm">cs@angkringankembang.com</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center text-lg">
                      <Clock className="mr-2 h-5 w-5" /> Jam Buka
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">Senin - Jumat: 10:00 - 22:00</p>
                    <p className="text-sm">Sabtu - Minggu: 08:00 - 23:00</p>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-8">
                <h3 className="text-xl font-semibold mb-4">Lokasi Kami</h3>
                <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                  <p className="text-muted-foreground">Peta akan ditampilkan di sini</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

