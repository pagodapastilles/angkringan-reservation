"use client"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import { id } from "date-fns/locale"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

export function DatePicker() {
  const router = useRouter()
  const searchParams = useSearchParams()

  // Gunakan tanggal dari query parameter atau tanggal hari ini
  const today = new Date()
  const dateParam = searchParams.get("date")
  const initialDate = dateParam ? new Date(dateParam) : today

  const [date, setDate] = useState<Date | undefined>(initialDate)

  const handleSelect = (selectedDate: Date | undefined) => {
    setDate(selectedDate)

    if (selectedDate) {
      const formattedDate = format(selectedDate, "yyyy-MM-dd")
      router.push(`/dapur?date=${formattedDate}`)
    }
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" className="border-batik-brown/30 bg-white hover:bg-white hover:text-batik-brown">
          <CalendarIcon className="mr-2 h-4 w-4 text-batik-gold" />
          {date ? format(date, "dd MMMM yyyy", { locale: id }) : <span>Pilih tanggal</span>}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0 bg-white border-batik-brown/30">
        <Calendar mode="single" selected={date} onSelect={handleSelect} initialFocus className="bg-white" />
      </PopoverContent>
    </Popover>
  )
}

