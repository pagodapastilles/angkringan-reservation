import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChefHat, Download, Printer } from "lucide-react"
import { getKitchenNeedsByDate } from "@/lib/supabase"
import { DatePicker } from "./date-picker"

export default async function DapurPage({
  searchParams,
}: {
  searchParams: { date?: string }
}) {
  // Gunakan tanggal dari query parameter atau tanggal hari ini
  const today = new Date().toISOString().split("T")[0]
  const selectedDate = searchParams.date || today

  // Ambil data kebutuhan dapur berdasarkan tanggal
  const kitchenNeeds = await getKitchenNeedsByDate(selectedDate)

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-8 bg-batik-cream/30">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-batik-brown font-javanese">Kebutuhan Dapur</h1>
            <div className="flex items-center gap-2 mt-4 md:mt-0">
              <DatePicker />
              <Button className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
                <Printer className="h-4 w-4 mr-2" />
                Cetak
              </Button>
              <Button className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
                <Download className="h-4 w-4 mr-2" />
                Ekspor PDF
              </Button>
            </div>
          </div>

          <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-batik-brown flex items-center gap-2">
                <ChefHat className="h-5 w-5 text-batik-gold" />
                Kebutuhan Dapur
              </CardTitle>
              <CardDescription>
                Tanggal:{" "}
                {new Date(selectedDate).toLocaleDateString("id-ID", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="makanan" className="w-full">
                <TabsList className="mb-6 bg-white/50 border border-batik-brown/20">
                  <TabsTrigger
                    value="makanan"
                    className="data-[state=active]:bg-batik-brown data-[state=active]:text-batik-cream"
                  >
                    Bahan Makanan
                  </TabsTrigger>
                  <TabsTrigger
                    value="minuman"
                    className="data-[state=active]:bg-batik-brown data-[state=active]:text-batik-cream"
                  >
                    Bahan Minuman
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="makanan">
                  {kitchenNeeds.makanan.length > 0 ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-12 gap-4 font-medium text-batik-brown border-b border-batik-brown/20 pb-2">
                        <div className="col-span-1 text-center">#</div>
                        <div className="col-span-5">Bahan</div>
                        <div className="col-span-2 text-center">Jumlah</div>
                        <div className="col-span-2 text-center">Satuan</div>
                        <div className="col-span-2 text-center">Status</div>
                      </div>

                      {kitchenNeeds.makanan.map((item, index) => (
                        <div
                          key={item.bahan.id}
                          className="grid grid-cols-12 gap-4 items-center p-3 border border-batik-brown/20 rounded-md bg-white"
                        >
                          <div className="col-span-1 text-center font-medium text-batik-brown/70">{index + 1}</div>
                          <div className="col-span-5 font-medium text-batik-brown">{item.bahan.nama}</div>
                          <div className="col-span-2 text-center">{item.jumlah}</div>
                          <div className="col-span-2 text-center">{item.bahan.satuan}</div>
                          <div className="col-span-2 text-center">
                            <span className="inline-block px-3 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">
                              Persiapan
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 text-batik-brown/50">
                      <ChefHat className="h-12 w-12 mx-auto mb-4 opacity-30" />
                      <p>Tidak ada kebutuhan bahan makanan untuk tanggal ini</p>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="minuman">
                  {kitchenNeeds.minuman.length > 0 ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-12 gap-4 font-medium text-batik-brown border-b border-batik-brown/20 pb-2">
                        <div className="col-span-1 text-center">#</div>
                        <div className="col-span-5">Bahan</div>
                        <div className="col-span-2 text-center">Jumlah</div>
                        <div className="col-span-2 text-center">Satuan</div>
                        <div className="col-span-2 text-center">Status</div>
                      </div>

                      {kitchenNeeds.minuman.map((item, index) => (
                        <div
                          key={item.bahan.id}
                          className="grid grid-cols-12 gap-4 items-center p-3 border border-batik-brown/20 rounded-md bg-white"
                        >
                          <div className="col-span-1 text-center font-medium text-batik-brown/70">{index + 1}</div>
                          <div className="col-span-5 font-medium text-batik-brown">{item.bahan.nama}</div>
                          <div className="col-span-2 text-center">{item.jumlah}</div>
                          <div className="col-span-2 text-center">{item.bahan.satuan}</div>
                          <div className="col-span-2 text-center">
                            <span className="inline-block px-3 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">
                              Persiapan
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 text-batik-brown/50">
                      <ChefHat className="h-12 w-12 mx-auto mb-4 opacity-30" />
                      <p>Tidak ada kebutuhan bahan minuman untuk tanggal ini</p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  )
}

