import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, ChefHat, Users, Utensils } from "lucide-react"
import Link from "next/link"
import { getReservations } from "@/lib/supabase"

export default async function DashboardPage() {
  const reservations = await getReservations()

  // Hitung jumlah reservasi hari ini
  const today = new Date().toISOString().split("T")[0]
  const reservasiHariIni = reservations.filter((res) => res.tanggal_reservasi === today)

  // Hitung total tamu hari ini
  const totalTamuHariIni = reservasiHariIni.reduce((total, res) => total + (res.jumlah_tamu || 0), 0)

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-8 bg-batik-cream/30">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-batik-brown font-javanese">Dashboard Admin</h1>
            <p className="text-batik-brown/70">
              {new Date().toLocaleDateString("id-ID", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
              <CardHeader className="pb-2">
                <CardDescription>Reservasi Hari Ini</CardDescription>
                <CardTitle className="text-3xl text-batik-brown flex justify-between items-center">
                  {reservasiHariIni.length}
                  <Calendar className="h-6 w-6 text-batik-gold" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-batik-brown/70">
                  {reservasiHariIni.length > 0
                    ? `${reservasiHariIni.length} reservasi terjadwal hari ini`
                    : "Tidak ada reservasi hari ini"}
                </p>
              </CardContent>
            </Card>

            <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
              <CardHeader className="pb-2">
                <CardDescription>Total Tamu Hari Ini</CardDescription>
                <CardTitle className="text-3xl text-batik-brown flex justify-between items-center">
                  {totalTamuHariIni}
                  <Users className="h-6 w-6 text-batik-gold" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-batik-brown/70">
                  {totalTamuHariIni > 0 ? `${totalTamuHariIni} tamu akan datang hari ini` : "Tidak ada tamu hari ini"}
                </p>
              </CardContent>
            </Card>

            <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
              <CardHeader className="pb-2">
                <CardDescription>Menu Populer</CardDescription>
                <CardTitle className="text-3xl text-batik-brown flex justify-between items-center">
                  5
                  <Utensils className="h-6 w-6 text-batik-gold" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-batik-brown/70">5 menu paling banyak dipesan minggu ini</p>
              </CardContent>
            </Card>

            <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
              <CardHeader className="pb-2">
                <CardDescription>Kebutuhan Dapur</CardDescription>
                <CardTitle className="text-3xl text-batik-brown flex justify-between items-center">
                  8
                  <ChefHat className="h-6 w-6 text-batik-gold" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-batik-brown/70">8 item perlu disiapkan untuk hari ini</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-batik-brown flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-batik-gold" />
                  Reservasi Terbaru
                </CardTitle>
                <CardDescription>Daftar 5 reservasi terbaru</CardDescription>
              </CardHeader>
              <CardContent>
                {reservations.length > 0 ? (
                  <div className="space-y-4">
                    {reservations.slice(0, 5).map((reservation) => (
                      <div
                        key={reservation.id}
                        className="flex justify-between items-center p-3 border border-batik-brown/20 rounded-md bg-white"
                      >
                        <div>
                          <h3 className="font-medium text-batik-brown">{reservation.nama_pemesan}</h3>
                          <p className="text-sm text-batik-brown/70">
                            {new Date(reservation.tanggal_reservasi).toLocaleDateString("id-ID")} -{" "}
                            {reservation.jam_reservasi}
                          </p>
                          <p className="text-sm text-batik-brown/70">{reservation.jumlah_tamu} orang</p>
                        </div>
                        <Link
                          href={`/reservasi/${reservation.id}`}
                          className="text-xs px-3 py-1 bg-batik-brown text-batik-cream rounded-full hover:bg-batik-darkGreen transition-colors"
                        >
                          Detail
                        </Link>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center py-8 text-batik-brown/50">Belum ada data reservasi</p>
                )}
                <div className="mt-4 text-center">
                  <Link
                    href="/reservasi"
                    className="text-sm text-batik-brown hover:text-batik-deepRed transition-colors"
                  >
                    Lihat Semua Reservasi
                  </Link>
                </div>
              </CardContent>
            </Card>

            <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-batik-brown flex items-center gap-2">
                  <ChefHat className="h-5 w-5 text-batik-gold" />
                  Kebutuhan Dapur Hari Ini
                </CardTitle>
                <CardDescription>Bahan yang perlu disiapkan</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="p-3 border border-batik-brown/20 rounded-md bg-white">
                    <h3 className="font-medium text-batik-brown">Nasi Putih</h3>
                    <p className="text-sm text-batik-brown/70">15 porsi</p>
                  </div>
                  <div className="p-3 border border-batik-brown/20 rounded-md bg-white">
                    <h3 className="font-medium text-batik-brown">Ayam Goreng</h3>
                    <p className="text-sm text-batik-brown/70">10 porsi</p>
                  </div>
                  <div className="p-3 border border-batik-brown/20 rounded-md bg-white">
                    <h3 className="font-medium text-batik-brown">Sayur Asem</h3>
                    <p className="text-sm text-batik-brown/70">8 porsi</p>
                  </div>
                </div>
                <div className="mt-4 text-center">
                  <Link href="/dapur" className="text-sm text-batik-brown hover:text-batik-deepRed transition-colors">
                    Lihat Semua Kebutuhan
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

