"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Leaf, Lock, User, Database, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { loginAdmin } from "@/lib/auth"
import { toast } from "@/hooks/use-toast"
import Link from "next/link"
import { supabase } from "@/lib/supabase"

export default function LoginPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [setupNeeded, setSetupNeeded] = useState(false)
  const [checkingSetup, setCheckingSetup] = useState(true)

  // Check if setup is needed
  useEffect(() => {
    async function checkSetup() {
      try {
        // Try to query the admin table
        const { error } = await supabase.from("admin").select("count").limit(1)

        // If there's an error about the table not existing, setup is needed
        if (error && error.message.includes("relation") && error.message.includes("does not exist")) {
          setSetupNeeded(true)
        }
      } catch (error) {
        console.error("Error checking setup:", error)
        setSetupNeeded(true)
      } finally {
        setCheckingSetup(false)
      }
    }

    checkSetup()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const admin = await loginAdmin(username, password)

      if (admin) {
        // Simpan informasi admin di localStorage
        localStorage.setItem("admin", JSON.stringify(admin))
        localStorage.setItem("loginTime", new Date().toISOString())

        toast({
          title: "Login berhasil",
          description: `Selamat datang, ${admin.nama}`,
        })

        router.push("/dashboard")
      } else {
        toast({
          title: "Login gagal",
          description: "Username atau password salah",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error logging in:", error)
      toast({
        title: "Login gagal",
        description: "Terjadi kesalahan saat login",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (checkingSetup) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-batik-cream/30 p-4">
        <div className="text-center">
          <Leaf className="h-12 w-12 text-batik-gold mx-auto mb-2 animate-pulse" />
          <p className="text-batik-brown">Memeriksa status database...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-batik-cream/30 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Leaf className="h-12 w-12 text-batik-gold mx-auto mb-2" />
          <h1 className="text-3xl font-bold text-batik-brown font-javanese">Angkringan Kembang</h1>
          <p className="text-batik-brown/70">Sistem Manajemen Reservasi</p>
        </div>

        {setupNeeded && (
          <Alert className="mb-6 border-amber-200 bg-amber-50">
            <Database className="h-4 w-4 text-amber-600" />
            <AlertTitle className="text-amber-800">Setup Database Diperlukan</AlertTitle>
            <AlertDescription className="text-amber-700">
              <p className="mb-2">Database belum diatur. Silakan lakukan setup terlebih dahulu.</p>
              <Link href="/setup">
                <Button size="sm" className="bg-amber-600 hover:bg-amber-700 text-white">
                  Lakukan Setup <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </AlertDescription>
          </Alert>
        )}

        <Card className="border-batik-brown/30 bg-white/90 backdrop-blur-sm shadow-lg">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-batik-brown text-center">Login Admin</CardTitle>
            <CardDescription className="text-center">Masukkan username dan password untuk melanjutkan</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-batik-brown">
                  Username
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-batik-brown/50" />
                  <Input
                    id="username"
                    placeholder="Masukkan username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold pl-10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-batik-brown">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-batik-brown/50" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="Masukkan password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold pl-10"
                  />
                </div>
              </div>
              <Button
                type="submit"
                className="w-full bg-batik-brown hover:bg-batik-darkGreen text-batik-cream"
                disabled={isLoading}
              >
                {isLoading ? "Memproses..." : "Login"}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="border-t border-batik-brown/10 pt-4">
            <p className="text-xs text-batik-brown/60 text-center w-full">
              &copy; {new Date().getFullYear()} Angkringan Kembang. Hanya untuk penggunaan internal.
            </p>
          </CardFooter>
        </Card>

        <div className="mt-4 text-center text-sm text-batik-brown/70">
          <p>Demo credentials:</p>
          <p>
            Username: <code className="bg-batik-brown/10 px-1 rounded">admin</code> | Password:{" "}
            <code className="bg-batik-brown/10 px-1 rounded">admin123</code>
          </p>
        </div>
      </div>
    </div>
  )
}

