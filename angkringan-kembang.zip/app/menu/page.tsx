import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"

export default async function MenuPage() {
  // In a real application, we would fetch this data from Supabase
  const menuCategories = [
    { id: "makanan", name: "Makanan" },
    { id: "minuman", name: "Minuman" },
    { id: "snack", name: "Snack" },
  ]

  const menuItems = {
    makanan: [
      { id: 1, name: "Nasi Kucing", price: 5000, description: "Nasi dengan lauk ayam suwir dan sambal" },
      { id: 2, name: "Sate Usus", price: 10000, description: "Sate usus ayam dengan bumbu kacang" },
      { id: 3, name: "Sate Telur Puyuh", price: 12000, description: "Sate telur puyuh dengan bumbu kacang" },
      { id: 4, name: "Oseng-oseng Tempe", price: 8000, description: "Tempe yang dioseng dengan cabai dan kecap" },
    ],
    minuman: [
      { id: 5, name: "Es Teh", price: 3000, description: "Teh manis dingin" },
      { id: 6, name: "Wedang Jahe", price: 5000, description: "Minuman jahe hangat" },
      { id: 7, name: "Kopi Hitam", price: 4000, description: "Kopi hitam tanpa gula" },
      { id: 8, name: "Es Jeruk", price: 4000, description: "Jeruk peras dingin" },
    ],
    snack: [
      { id: 9, name: "Gorengan Tempe", price: 2000, description: "Tempe goreng dengan tepung" },
      { id: 10, name: "Gorengan Tahu", price: 2000, description: "Tahu goreng dengan tepung" },
      { id: 11, name: "Pisang Goreng", price: 3000, description: "Pisang goreng dengan tepung" },
      { id: 12, name: "Singkong Goreng", price: 3000, description: "Singkong goreng dengan tepung" },
    ],
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-12">
        <div className="container">
          <h1 className="text-3xl font-bold mb-8">Menu Kami</h1>

          <Tabs defaultValue="makanan" className="w-full">
            <TabsList className="mb-8">
              {menuCategories.map((category) => (
                <TabsTrigger key={category.id} value={category.id}>
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>

            {menuCategories.map((category) => (
              <TabsContent key={category.id} value={category.id}>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {menuItems[category.id as keyof typeof menuItems].map((item) => (
                    <Card key={item.id}>
                      <div className="aspect-video relative">
                        <Image
                          src={`/placeholder.svg?height=200&width=400&text=${encodeURIComponent(item.name)}`}
                          alt={item.name}
                          fill
                          className="object-cover rounded-t-lg"
                        />
                      </div>
                      <CardHeader>
                        <CardTitle>{item.name}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">{item.description}</p>
                        <p className="font-semibold mt-2">Rp {item.price.toLocaleString()}</p>
                      </CardContent>
                      <CardFooter>
                        <Button className="w-full">Tambahkan ke Keranjang</Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  )
}

