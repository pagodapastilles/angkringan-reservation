import Link from "next/link"
import { Leaf } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-4 text-center bg-batik-cream/30">
      <Leaf className="h-16 w-16 mb-4 text-batik-gold" />
      <h1 className="text-4xl font-bold mb-2 text-batik-brown font-javanese">404</h1>
      <h2 className="text-2xl font-semibold mb-4 text-batik-brown">Halaman Tidak Ditemukan</h2>
      <p className="text-batik-brown/70 mb-8 max-w-md">
        Maaf, halaman yang Anda cari tidak dapat ditemukan. Mungkin halaman telah dipindahkan atau dihapus.
      </p>
      <Button asChild className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
        <Link href="/dashboard">Kembali ke Dashboard</Link>
      </Button>
    </div>
  )
}

