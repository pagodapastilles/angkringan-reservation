"use client"

import { useEffect, useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Search, Edit, Trash2 } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { toast } from "@/hooks/use-toast"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface KategoriBahan {
  id: number
  nama: string
}

interface Bahan {
  id: number
  nama: string
  satuan: string
  kategori_id: number
  kategori?: {
    id: number
    nama: string
  }
}

export default function BahanPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [bahans, setBahans] = useState<Bahan[]>([])
  const [kategoris, setKategoris] = useState<KategoriBahan[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // State untuk dialog tambah bahan
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [namaBahan, setNamaBahan] = useState("")
  const [satuanBahan, setSatuanBahan] = useState("")
  const [kategoriBahanId, setKategoriBahanId] = useState<string>("")

  // State untuk dialog edit bahan
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingBahan, setEditingBahan] = useState<Bahan | null>(null)

  useEffect(() => {
    fetchBahans()
    fetchKategoriBahan()
  }, [])

  async function fetchBahans() {
    setIsLoading(true)
    try {
      const { data, error } = await supabase
        .from("bahan")
        .select(`
          *,
          kategori:kategori_id(id, nama)
        `)
        .order("nama")

      if (error) {
        throw error
      }

      setBahans(data || [])
    } catch (error) {
      console.error("Error fetching bahans:", error)
      toast({
        title: "Gagal memuat data bahan",
        description: "Terjadi kesalahan saat memuat data bahan",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  async function fetchKategoriBahan() {
    try {
      const { data, error } = await supabase.from("kategori_bahan").select("*").order("nama")

      if (error) {
        throw error
      }

      setKategoris(data || [])
    } catch (error) {
      console.error("Error fetching kategori bahan:", error)
      toast({
        title: "Gagal memuat kategori bahan",
        description: "Terjadi kesalahan saat memuat kategori bahan",
        variant: "destructive",
      })
    }
  }

  async function handleAddBahan() {
    setIsSubmitting(true)
    try {
      // Validasi
      if (!namaBahan) {
        throw new Error("Nama bahan harus diisi")
      }

      if (!satuanBahan) {
        throw new Error("Satuan bahan harus diisi")
      }

      if (!kategoriBahanId) {
        throw new Error("Kategori bahan harus dipilih")
      }

      const { data, error } = await supabase
        .from("bahan")
        .insert([
          {
            nama: namaBahan,
            satuan: satuanBahan,
            kategori_id: Number.parseInt(kategoriBahanId),
          },
        ])
        .select(`
          *,
          kategori:kategori_id(id, nama)
        `)

      if (error) {
        throw error
      }

      setBahans([...bahans, ...data])
      setNamaBahan("")
      setSatuanBahan("")
      setKategoriBahanId("")
      setIsAddDialogOpen(false)

      toast({
        title: "Bahan berhasil ditambahkan",
        description: `Bahan ${namaBahan} telah berhasil ditambahkan`,
      })
    } catch (error: any) {
      console.error("Error adding bahan:", error)
      toast({
        title: "Gagal menambahkan bahan",
        description: error.message || "Terjadi kesalahan saat menyimpan data bahan",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  function handleEditClick(bahan: Bahan) {
    setEditingBahan(bahan)
    setNamaBahan(bahan.nama)
    setSatuanBahan(bahan.satuan)
    setKategoriBahanId(bahan.kategori_id.toString())
    setIsEditDialogOpen(true)
  }

  async function handleUpdateBahan() {
    if (!editingBahan) return

    setIsSubmitting(true)
    try {
      // Validasi
      if (!namaBahan) {
        throw new Error("Nama bahan harus diisi")
      }

      if (!satuanBahan) {
        throw new Error("Satuan bahan harus diisi")
      }

      if (!kategoriBahanId) {
        throw new Error("Kategori bahan harus dipilih")
      }

      const { data, error } = await supabase
        .from("bahan")
        .update({
          nama: namaBahan,
          satuan: satuanBahan,
          kategori_id: Number.parseInt(kategoriBahanId),
        })
        .eq("id", editingBahan.id)
        .select(`
          *,
          kategori:kategori_id(id, nama)
        `)

      if (error) {
        throw error
      }

      // Update local state
      setBahans(bahans.map((b) => (b.id === editingBahan.id ? data[0] : b)))

      setIsEditDialogOpen(false)
      setEditingBahan(null)
      setNamaBahan("")
      setSatuanBahan("")
      setKategoriBahanId("")

      toast({
        title: "Bahan berhasil diperbarui",
        description: `Bahan ${namaBahan} telah berhasil diperbarui`,
      })
    } catch (error: any) {
      console.error("Error updating bahan:", error)
      toast({
        title: "Gagal memperbarui bahan",
        description: error.message || "Terjadi kesalahan saat memperbarui data bahan",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleDeleteBahan(id: number, name: string) {
    if (!confirm(`Anda yakin ingin menghapus bahan "${name}"?`)) {
      return
    }

    try {
      const { error } = await supabase.from("bahan").delete().eq("id", id)

      if (error) {
        throw error
      }

      // Remove item from local state
      setBahans((prev) => prev.filter((bahan) => bahan.id !== id))

      toast({
        title: "Bahan berhasil dihapus",
        description: `Bahan "${name}" telah dihapus`,
      })
    } catch (error) {
      console.error("Error deleting bahan:", error)
      toast({
        title: "Gagal menghapus bahan",
        description: "Terjadi kesalahan saat menghapus bahan",
        variant: "destructive",
      })
    }
  }

  // Filter bahan berdasarkan search term
  const filteredBahans = bahans.filter(
    (bahan) =>
      bahan.nama.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bahan.satuan.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bahan.kategori?.nama.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-8 bg-batik-cream/30">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-batik-brown font-javanese">Manajemen Bahan</h1>
            <div className="flex items-center gap-2 mt-4 md:mt-0">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-batik-brown/50" />
                <Input
                  type="search"
                  placeholder="Cari bahan..."
                  className="pl-8 bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
                    <Plus className="h-4 w-4 mr-2" />
                    Tambah Bahan
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-white border-batik-brown/30 sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle className="text-batik-brown">Tambah Bahan Baru</DialogTitle>
                    <DialogDescription>Tambahkan bahan baru untuk resep</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="nama_bahan" className="text-batik-brown">
                        Nama Bahan
                      </Label>
                      <Input
                        id="nama_bahan"
                        value={namaBahan}
                        onChange={(e) => setNamaBahan(e.target.value)}
                        className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
                        placeholder="Contoh: Bawang Merah"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="satuan_bahan" className="text-batik-brown">
                        Satuan
                      </Label>
                      <Input
                        id="satuan_bahan"
                        value={satuanBahan}
                        onChange={(e) => setSatuanBahan(e.target.value)}
                        className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
                        placeholder="Contoh: gram, kg, liter, buah"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="kategori_bahan" className="text-batik-brown">
                        Kategori
                      </Label>
                      <Select value={kategoriBahanId} onValueChange={setKategoriBahanId}>
                        <SelectTrigger className="bg-white border-batik-brown/30 focus:ring-batik-gold">
                          <SelectValue placeholder="Pilih kategori" />
                        </SelectTrigger>
                        <SelectContent>
                          {kategoris.map((kategori) => (
                            <SelectItem key={kategori.id} value={kategori.id.toString()}>
                              {kategori.nama}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsAddDialogOpen(false)}
                      className="border-batik-brown text-batik-brown hover:bg-batik-brown/10"
                    >
                      Batal
                    </Button>
                    <Button
                      onClick={handleAddBahan}
                      disabled={isSubmitting || !namaBahan || !satuanBahan || !kategoriBahanId}
                      className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream"
                    >
                      {isSubmitting ? "Menyimpan..." : "Simpan Bahan"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-batik-brown">Daftar Bahan</CardTitle>
              <CardDescription>Kelola bahan-bahan untuk resep di sini</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-10">
                  <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-batik-brown border-r-transparent"></div>
                  <p className="mt-2 text-batik-brown/70">Memuat data bahan...</p>
                </div>
              ) : filteredBahans.length === 0 ? (
                <div className="text-center py-12 text-batik-brown/50">
                  <p>Tidak ada bahan ditemukan</p>
                  <Button
                    onClick={() => setIsAddDialogOpen(true)}
                    className="mt-4 bg-batik-brown hover:bg-batik-darkGreen text-batik-cream"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Tambah Bahan Baru
                  </Button>
                </div>
              ) : (
                <div className="border border-batik-brown/20 rounded-md overflow-hidden">
                  <Table>
                    <TableHeader className="bg-batik-brown/5">
                      <TableRow>
                        <TableHead className="text-batik-brown">Nama Bahan</TableHead>
                        <TableHead className="text-batik-brown">Kategori</TableHead>
                        <TableHead className="text-batik-brown">Satuan</TableHead>
                        <TableHead className="text-batik-brown text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredBahans.map((bahan) => (
                        <TableRow key={bahan.id}>
                          <TableCell className="font-medium">{bahan.nama}</TableCell>
                          <TableCell>{bahan.kategori?.nama}</TableCell>
                          <TableCell>{bahan.satuan}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEditClick(bahan)}
                                className="h-8 text-batik-brown hover:text-batik-deepRed hover:bg-batik-brown/10"
                              >
                                <Edit className="h-4 w-4 mr-1" />
                                Edit
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteBahan(bahan.id, bahan.nama)}
                                className="h-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                              >
                                <Trash2 className="h-4 w-4 mr-1" />
                                Hapus
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />

      {/* Dialog Edit Bahan */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-white border-batik-brown/30 sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="text-batik-brown">Edit Bahan</DialogTitle>
            <DialogDescription>Perbarui informasi bahan</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit_nama_bahan" className="text-batik-brown">
                Nama Bahan
              </Label>
              <Input
                id="edit_nama_bahan"
                value={namaBahan}
                onChange={(e) => setNamaBahan(e.target.value)}
                className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit_satuan_bahan" className="text-batik-brown">
                Satuan
              </Label>
              <Input
                id="edit_satuan_bahan"
                value={satuanBahan}
                onChange={(e) => setSatuanBahan(e.target.value)}
                className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit_kategori_bahan" className="text-batik-brown">
                Kategori
              </Label>
              <Select value={kategoriBahanId} onValueChange={setKategoriBahanId}>
                <SelectTrigger className="bg-white border-batik-brown/30 focus:ring-batik-gold">
                  <SelectValue placeholder="Pilih kategori" />
                </SelectTrigger>
                <SelectContent>
                  {kategoris.map((kategori) => (
                    <SelectItem key={kategori.id} value={kategori.id.toString()}>
                      {kategori.nama}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIsEditDialogOpen(false)
                setEditingBahan(null)
              }}
              className="border-batik-brown text-batik-brown hover:bg-batik-brown/10"
            >
              Batal
            </Button>
            <Button
              onClick={handleUpdateBahan}
              disabled={isSubmitting || !namaBahan || !satuanBahan || !kategoriBahanId}
              className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream"
            >
              {isSubmitting ? "Menyimpan..." : "Perbarui Bahan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

