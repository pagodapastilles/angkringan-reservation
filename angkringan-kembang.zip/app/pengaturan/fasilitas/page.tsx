"use client"

import { useEffect, useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Search, Edit, Trash2, Music } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { toast } from "@/hooks/use-toast"
import { Label } from "@/components/ui/label"

interface Fasilitas {
  id: number
  nama: string
  biaya: number
  deskripsi?: string
}

export default function FasilitasPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [fasilitas, setFasilitas] = useState<Fasilitas[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // State untuk dialog tambah fasilitas
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [namaFasilitas, setNamaFasilitas] = useState("")
  const [biayaFasilitas, setBiayaFasilitas] = useState<number>(0)
  const [deskripsiFasilitas, setDeskripsiFasilitas] = useState("")

  // State untuk dialog edit fasilitas
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingFasilitas, setEditingFasilitas] = useState<Fasilitas | null>(null)

  useEffect(() => {
    fetchFasilitas()
  }, [])

  async function fetchFasilitas() {
    setIsLoading(true)
    try {
      const { data, error } = await supabase.from("fasilitas_tambahan").select("*").order("nama")

      if (error) {
        throw error
      }

      setFasilitas(data || [])
    } catch (error) {
      console.error("Error fetching fasilitas:", error)
      toast({
        title: "Gagal memuat data fasilitas",
        description: "Terjadi kesalahan saat memuat data fasilitas",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  async function handleAddFasilitas() {
    setIsSubmitting(true)
    try {
      // Validasi
      if (!namaFasilitas) {
        throw new Error("Nama fasilitas harus diisi")
      }

      if (biayaFasilitas < 0) {
        throw new Error("Biaya tidak boleh negatif")
      }

      const { data, error } = await supabase
        .from("fasilitas_tambahan")
        .insert([
          {
            nama: namaFasilitas,
            biaya: biayaFasilitas,
            deskripsi: deskripsiFasilitas || null,
          },
        ])
        .select()

      if (error) {
        throw error
      }

      setFasilitas([...fasilitas, ...data])
      setNamaFasilitas("")
      setBiayaFasilitas(0)
      setDeskripsiFasilitas("")
      setIsAddDialogOpen(false)

      toast({
        title: "Fasilitas berhasil ditambahkan",
        description: `Fasilitas ${namaFasilitas} telah berhasil ditambahkan`,
      })
    } catch (error: any) {
      console.error("Error adding fasilitas:", error)
      toast({
        title: "Gagal menambahkan fasilitas",
        description: error.message || "Terjadi kesalahan saat menyimpan data fasilitas",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  function handleEditClick(fasilitas: Fasilitas) {
    setEditingFasilitas(fasilitas)
    setNamaFasilitas(fasilitas.nama)
    setBiayaFasilitas(fasilitas.biaya)
    setDeskripsiFasilitas(fasilitas.deskripsi || "")
    setIsEditDialogOpen(true)
  }

  async function handleUpdateFasilitas() {
    if (!editingFasilitas) return

    setIsSubmitting(true)
    try {
      // Validasi
      if (!namaFasilitas) {
        throw new Error("Nama fasilitas harus diisi")
      }

      if (biayaFasilitas < 0) {
        throw new Error("Biaya tidak boleh negatif")
      }

      const { data, error } = await supabase
        .from("fasilitas_tambahan")
        .update({
          nama: namaFasilitas,
          biaya: biayaFasilitas,
          deskripsi: deskripsiFasilitas || null,
        })
        .eq("id", editingFasilitas.id)
        .select()

      if (error) {
        throw error
      }

      // Update local state
      setFasilitas(fasilitas.map((f) => (f.id === editingFasilitas.id ? data[0] : f)))

      setIsEditDialogOpen(false)
      setEditingFasilitas(null)
      setNamaFasilitas("")
      setBiayaFasilitas(0)
      setDeskripsiFasilitas("")

      toast({
        title: "Fasilitas berhasil diperbarui",
        description: `Fasilitas ${namaFasilitas} telah berhasil diperbarui`,
      })
    } catch (error: any) {
      console.error("Error updating fasilitas:", error)
      toast({
        title: "Gagal memperbarui fasilitas",
        description: error.message || "Terjadi kesalahan saat memperbarui data fasilitas",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleDeleteFasilitas(id: number, name: string) {
    if (!confirm(`Anda yakin ingin menghapus fasilitas "${name}"?`)) {
      return
    }

    try {
      const { error } = await supabase.from("fasilitas_tambahan").delete().eq("id", id)

      if (error) {
        throw error
      }

      // Remove item from local state
      setFasilitas((prev) => prev.filter((f) => f.id !== id))

      toast({
        title: "Fasilitas berhasil dihapus",
        description: `Fasilitas "${name}" telah dihapus`,
      })
    } catch (error) {
      console.error("Error deleting fasilitas:", error)
      toast({
        title: "Gagal menghapus fasilitas",
        description: "Terjadi kesalahan saat menghapus fasilitas",
        variant: "destructive",
      })
    }
  }

  // Filter fasilitas berdasarkan search term
  const filteredFasilitas = fasilitas.filter(
    (f) =>
      f.nama.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.deskripsi?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-8 bg-batik-cream/30">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-batik-brown font-javanese">Manajemen Fasilitas Tambahan</h1>
            <div className="flex items-center gap-2 mt-4 md:mt-0">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-batik-brown/50" />
                <Input
                  type="search"
                  placeholder="Cari fasilitas..."
                  className="pl-8 bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
                    <Plus className="h-4 w-4 mr-2" />
                    Tambah Fasilitas
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-white border-batik-brown/30 sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle className="text-batik-brown">Tambah Fasilitas Baru</DialogTitle>
                    <DialogDescription>Tambahkan fasilitas tambahan untuk reservasi</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="nama_fasilitas" className="text-batik-brown">
                        Nama Fasilitas
                      </Label>
                      <Input
                        id="nama_fasilitas"
                        value={namaFasilitas}
                        onChange={(e) => setNamaFasilitas(e.target.value)}
                        className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
                        placeholder="Contoh: Dekorasi Khusus"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="biaya_fasilitas" className="text-batik-brown">
                        Biaya Tambahan
                      </Label>
                      <div className="relative">
                        <span className="absolute left-3 top-2.5 text-batik-brown/70">Rp</span>
                        <Input
                          id="biaya_fasilitas"
                          type="number"
                          min="0"
                          value={biayaFasilitas}
                          onChange={(e) => setBiayaFasilitas(Number(e.target.value))}
                          className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold pl-10"
                          placeholder="0"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="deskripsi_fasilitas" className="text-batik-brown">
                        Deskripsi
                      </Label>
                      <Textarea
                        id="deskripsi_fasilitas"
                        value={deskripsiFasilitas}
                        onChange={(e) => setDeskripsiFasilitas(e.target.value)}
                        className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold min-h-[100px]"
                        placeholder="Deskripsi singkat tentang fasilitas"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsAddDialogOpen(false)}
                      className="border-batik-brown text-batik-brown hover:bg-batik-brown/10"
                    >
                      Batal
                    </Button>
                    <Button
                      onClick={handleAddFasilitas}
                      disabled={isSubmitting || !namaFasilitas}
                      className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream"
                    >
                      {isSubmitting ? "Menyimpan..." : "Simpan Fasilitas"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-batik-brown">Daftar Fasilitas Tambahan</CardTitle>
              <CardDescription>Kelola fasilitas tambahan untuk reservasi di sini</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-10">
                  <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-batik-brown border-r-transparent"></div>
                  <p className="mt-2 text-batik-brown/70">Memuat data fasilitas...</p>
                </div>
              ) : filteredFasilitas.length === 0 ? (
                <div className="text-center py-12 text-batik-brown/50">
                  <Music className="h-12 w-12 mx-auto mb-4 opacity-30" />
                  <p>Tidak ada fasilitas tambahan ditemukan</p>
                  <Button
                    onClick={() => setIsAddDialogOpen(true)}
                    className="mt-4 bg-batik-brown hover:bg-batik-darkGreen text-batik-cream"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Tambah Fasilitas Baru
                  </Button>
                </div>
              ) : (
                <div className="border border-batik-brown/20 rounded-md overflow-hidden">
                  <Table>
                    <TableHeader className="bg-batik-brown/5">
                      <TableRow>
                        <TableHead className="text-batik-brown">Nama Fasilitas</TableHead>
                        <TableHead className="text-batik-brown text-right">Biaya</TableHead>
                        <TableHead className="text-batik-brown">Deskripsi</TableHead>
                        <TableHead className="text-batik-brown text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredFasilitas.map((f) => (
                        <TableRow key={f.id}>
                          <TableCell className="font-medium">{f.nama}</TableCell>
                          <TableCell className="text-right">Rp {f.biaya.toLocaleString()}</TableCell>
                          <TableCell>{f.deskripsi || "-"}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEditClick(f)}
                                className="h-8 text-batik-brown hover:text-batik-deepRed hover:bg-batik-brown/10"
                              >
                                <Edit className="h-4 w-4 mr-1" />
                                Edit
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteFasilitas(f.id, f.nama)}
                                className="h-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                              >
                                <Trash2 className="h-4 w-4 mr-1" />
                                Hapus
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />

      {/* Dialog Edit Fasilitas */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-white border-batik-brown/30 sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="text-batik-brown">Edit Fasilitas</DialogTitle>
            <DialogDescription>Perbarui informasi fasilitas tambahan</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit_nama_fasilitas" className="text-batik-brown">
                Nama Fasilitas
              </Label>
              <Input
                id="edit_nama_fasilitas"
                value={namaFasilitas}
                onChange={(e) => setNamaFasilitas(e.target.value)}
                className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit_biaya_fasilitas" className="text-batik-brown">
                Biaya Tambahan
              </Label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-batik-brown/70">Rp</span>
                <Input
                  id="edit_biaya_fasilitas"
                  type="number"
                  min="0"
                  value={biayaFasilitas}
                  onChange={(e) => setBiayaFasilitas(Number(e.target.value))}
                  className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold pl-10"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit_deskripsi_fasilitas" className="text-batik-brown">
                Deskripsi
              </Label>
              <Textarea
                id="edit_deskripsi_fasilitas"
                value={deskripsiFasilitas}
                onChange={(e) => setDeskripsiFasilitas(e.target.value)}
                className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold min-h-[100px]"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIsEditDialogOpen(false)
                setEditingFasilitas(null)
              }}
              className="border-batik-brown text-batik-brown hover:bg-batik-brown/10"
            >
              Batal
            </Button>
            <Button
              onClick={handleUpdateFasilitas}
              disabled={isSubmitting || !namaFasilitas}
              className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream"
            >
              {isSubmitting ? "Menyimpan..." : "Perbarui Fasilitas"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

