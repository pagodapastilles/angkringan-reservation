"use client"

import { useEffect, useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Search, Edit, Trash2, Check, X } from "lucide-react"
import { supabase } from "@/lib/supabase"
import Link from "next/link"
import { toast } from "@/hooks/use-toast"

interface MenuItem {
  id: number
  nama: string
  kategori_id: number
  harga: number
  deskripsi?: string
  tersedia: boolean
  is_paket: boolean
  kategori?: {
    id: number
    nama: string
  }
}

export default function MenuPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [menuItems, setMenuItems] = useState<MenuItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("semua")

  useEffect(() => {
    fetchMenuItems()
  }, [])

  async function fetchMenuItems() {
    setIsLoading(true)
    try {
      const { data, error } = await supabase
        .from("menu")
        .select(`
          *,
          kategori:kategori_id(id, nama)
        `)
        .order("nama")

      if (error) {
        throw error
      }

      setMenuItems(data || [])
    } catch (error) {
      console.error("Error fetching menu items:", error)
      toast({
        title: "Gagal memuat data menu",
        description: "Terjadi kesalahan saat memuat data menu",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  async function toggleMenuAvailability(id: number, currentStatus: boolean) {
    try {
      const { error } = await supabase.from("menu").update({ tersedia: !currentStatus }).eq("id", id)

      if (error) {
        throw error
      }

      // Update local state to reflect change
      setMenuItems((prev) => prev.map((item) => (item.id === id ? { ...item, tersedia: !currentStatus } : item)))

      toast({
        title: "Status menu berhasil diubah",
        description: `Menu sekarang ${!currentStatus ? "tersedia" : "tidak tersedia"}`,
      })
    } catch (error) {
      console.error("Error toggling menu availability:", error)
      toast({
        title: "Gagal mengubah status menu",
        description: "Terjadi kesalahan saat mengubah status menu",
        variant: "destructive",
      })
    }
  }

  async function deleteMenuItem(id: number, name: string) {
    if (!confirm(`Anda yakin ingin menghapus menu "${name}"?`)) {
      return
    }

    try {
      const { error } = await supabase.from("menu").delete().eq("id", id)

      if (error) {
        throw error
      }

      // Remove item from local state
      setMenuItems((prev) => prev.filter((item) => item.id !== id))

      toast({
        title: "Menu berhasil dihapus",
        description: `Menu "${name}" telah dihapus`,
      })
    } catch (error) {
      console.error("Error deleting menu item:", error)
      toast({
        title: "Gagal menghapus menu",
        description: "Terjadi kesalahan saat menghapus menu",
        variant: "destructive",
      })
    }
  }

  // Filter menu berdasarkan tab dan search term
  const filteredMenu = menuItems.filter((item) => {
    const matchesSearch =
      item.nama.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.deskripsi?.toLowerCase().includes(searchTerm.toLowerCase())

    if (activeTab === "semua") {
      return matchesSearch
    } else if (activeTab === "makanan") {
      return matchesSearch && item.kategori?.nama === "Makanan"
    } else if (activeTab === "minuman") {
      return matchesSearch && item.kategori?.nama === "Minuman"
    } else if (activeTab === "paket") {
      return matchesSearch && item.is_paket
    } else if (activeTab === "camilan") {
      return matchesSearch && item.kategori?.nama === "Camilan"
    }

    return matchesSearch
  })

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-8 bg-batik-cream/30">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-batik-brown font-javanese">Manajemen Menu</h1>
            <div className="flex items-center gap-2 mt-4 md:mt-0">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-batik-brown/50" />
                <Input
                  type="search"
                  placeholder="Cari menu..."
                  className="pl-8 bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Button asChild className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
                <Link href="/pengaturan/menu/tambah">
                  <Plus className="h-4 w-4 mr-2" />
                  Tambah Menu
                </Link>
              </Button>
            </div>
          </div>

          <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-batik-brown">Daftar Menu</CardTitle>
              <CardDescription>Kelola menu makanan, minuman, dan paket di sini</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="semua" value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="mb-6 bg-white/50 border border-batik-brown/20">
                  <TabsTrigger
                    value="semua"
                    className="data-[state=active]:bg-batik-brown data-[state=active]:text-batik-cream"
                  >
                    Semua Menu
                  </TabsTrigger>
                  <TabsTrigger
                    value="makanan"
                    className="data-[state=active]:bg-batik-brown data-[state=active]:text-batik-cream"
                  >
                    Makanan
                  </TabsTrigger>
                  <TabsTrigger
                    value="minuman"
                    className="data-[state=active]:bg-batik-brown data-[state=active]:text-batik-cream"
                  >
                    Minuman
                  </TabsTrigger>
                  <TabsTrigger
                    value="paket"
                    className="data-[state=active]:bg-batik-brown data-[state=active]:text-batik-cream"
                  >
                    Paket
                  </TabsTrigger>
                  <TabsTrigger
                    value="camilan"
                    className="data-[state=active]:bg-batik-brown data-[state=active]:text-batik-cream"
                  >
                    Camilan
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="semua">{renderMenuTable(filteredMenu)}</TabsContent>
                <TabsContent value="makanan">{renderMenuTable(filteredMenu)}</TabsContent>
                <TabsContent value="minuman">{renderMenuTable(filteredMenu)}</TabsContent>
                <TabsContent value="paket">{renderMenuTable(filteredMenu)}</TabsContent>
                <TabsContent value="camilan">{renderMenuTable(filteredMenu)}</TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  )

  function renderMenuTable(items: MenuItem[]) {
    if (isLoading) {
      return (
        <div className="text-center py-10">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-batik-brown border-r-transparent"></div>
          <p className="mt-2 text-batik-brown/70">Memuat data menu...</p>
        </div>
      )
    }

    if (items.length === 0) {
      return (
        <div className="text-center py-12 text-batik-brown/50">
          <p>Tidak ada menu ditemukan</p>
          <Button asChild className="mt-4 bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
            <Link href="/pengaturan/menu/tambah">
              <Plus className="h-4 w-4 mr-2" />
              Tambah Menu Baru
            </Link>
          </Button>
        </div>
      )
    }

    return (
      <div className="border border-batik-brown/20 rounded-md overflow-hidden">
        <Table>
          <TableHeader className="bg-batik-brown/5">
            <TableRow>
              <TableHead className="text-batik-brown">Nama Menu</TableHead>
              <TableHead className="text-batik-brown">Kategori</TableHead>
              <TableHead className="text-batik-brown text-right">Harga</TableHead>
              <TableHead className="text-batik-brown text-center">Tersedia</TableHead>
              <TableHead className="text-batik-brown text-right">Aksi</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="font-medium">
                  {item.nama}
                  {item.deskripsi && <p className="text-xs text-batik-brown/60 mt-1">{item.deskripsi}</p>}
                </TableCell>
                <TableCell>
                  <span
                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      item.is_paket
                        ? "bg-purple-100 text-purple-800"
                        : item.kategori?.nama === "Makanan"
                          ? "bg-blue-100 text-blue-800"
                          : item.kategori?.nama === "Minuman"
                            ? "bg-green-100 text-green-800"
                            : "bg-yellow-100 text-yellow-800"
                    }`}
                  >
                    {item.is_paket ? "Paket" : item.kategori?.nama}
                  </span>
                </TableCell>
                <TableCell className="text-right">Rp {item.harga.toLocaleString()}</TableCell>
                <TableCell className="text-center">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleMenuAvailability(item.id, item.tersedia)}
                    className={`h-8 w-8 p-0 ${
                      item.tersedia
                        ? "text-green-600 hover:text-green-700 hover:bg-green-50"
                        : "text-red-500 hover:text-red-700 hover:bg-red-50"
                    }`}
                  >
                    {item.tersedia ? <Check className="h-4 w-4" /> : <X className="h-4 w-4" />}
                  </Button>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      asChild
                      className="h-8 text-batik-brown hover:text-batik-deepRed hover:bg-batik-brown/10"
                    >
                      <Link href={`/pengaturan/menu/edit/${item.id}`}>
                        <Edit className="h-4 w-4 mr-1" />
                        Edit
                      </Link>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteMenuItem(item.id, item.nama)}
                      className="h-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Hapus
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    )
  }
}

