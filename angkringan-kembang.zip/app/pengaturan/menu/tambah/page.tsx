"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { ChevronLeft, Save } from "lucide-react"
import Link from "next/link"
import { supabase } from "@/lib/supabase"
import { toast } from "@/hooks/use-toast"

interface KategoriMenu {
  id: number
  nama: string
}

export default function TambahMenuPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [kategoriList, setKategoriList] = useState<KategoriMenu[]>([])

  const [nama, setNama] = useState("")
  const [kategoriId, setKategoriId] = useState<string>("")
  const [harga, setHarga] = useState<number>(0)
  const [deskripsi, setDeskripsi] = useState("")
  const [tersedia, setTersedia] = useState(true)
  const [isPaket, setIsPaket] = useState(false)

  useEffect(() => {
    fetchKategoriMenu()
  }, [])

  async function fetchKategoriMenu() {
    try {
      const { data, error } = await supabase.from("kategori_menu").select("id, nama").order("nama")

      if (error) {
        throw error
      }

      setKategoriList(data || [])
    } catch (error) {
      console.error("Error fetching kategori menu:", error)
      toast({
        title: "Gagal memuat kategori menu",
        description: "Terjadi kesalahan saat memuat data kategori",
        variant: "destructive",
      })
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Validasi
      if (!nama) {
        throw new Error("Nama menu harus diisi")
      }

      if (!kategoriId) {
        throw new Error("Kategori harus dipilih")
      }

      if (harga <= 0) {
        throw new Error("Harga harus lebih dari 0")
      }

      const { data, error } = await supabase
        .from("menu")
        .insert([
          {
            nama,
            kategori_id: Number.parseInt(kategoriId),
            harga,
            deskripsi: deskripsi || null,
            tersedia,
            is_paket: isPaket,
          },
        ])
        .select()

      if (error) {
        throw error
      }

      toast({
        title: "Menu berhasil ditambahkan",
        description: `Menu ${nama} telah berhasil ditambahkan`,
      })

      router.push("/pengaturan/menu")
    } catch (error: any) {
      console.error("Error adding menu:", error)
      toast({
        title: "Gagal menambahkan menu",
        description: error.message || "Terjadi kesalahan saat menyimpan data menu",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-8 bg-batik-cream/30">
        <div className="container">
          <div className="flex items-center mb-8">
            <Link href="/pengaturan/menu" className="text-batik-brown hover:text-batik-deepRed mr-4">
              <ChevronLeft className="h-5 w-5" />
            </Link>
            <h1 className="text-3xl font-bold text-batik-brown font-javanese">Tambah Menu Baru</h1>
          </div>

          <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-batik-brown">Form Menu</CardTitle>
              <CardDescription>Isi informasi menu baru</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="nama" className="text-batik-brown">
                        Nama Menu <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="nama"
                        value={nama}
                        onChange={(e) => setNama(e.target.value)}
                        required
                        className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
                        placeholder="Contoh: Nasi Goreng Spesial"
                      />
                    </div>

                    <div>
                      <Label htmlFor="kategori" className="text-batik-brown">
                        Kategori <span className="text-red-500">*</span>
                      </Label>
                      <Select value={kategoriId} onValueChange={setKategoriId} required>
                        <SelectTrigger className="bg-white border-batik-brown/30 focus:ring-batik-gold">
                          <SelectValue placeholder="Pilih kategori" />
                        </SelectTrigger>
                        <SelectContent>
                          {kategoriList.map((kategori) => (
                            <SelectItem key={kategori.id} value={kategori.id.toString()}>
                              {kategori.nama}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="harga" className="text-batik-brown">
                        Harga <span className="text-red-500">*</span>
                      </Label>
                      <div className="relative">
                        <span className="absolute left-3 top-2.5 text-batik-brown/70">Rp</span>
                        <Input
                          id="harga"
                          type="number"
                          min="0"
                          value={harga}
                          onChange={(e) => setHarga(Number(e.target.value))}
                          required
                          className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold pl-10"
                          placeholder="0"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="deskripsi" className="text-batik-brown">
                        Deskripsi
                      </Label>
                      <Textarea
                        id="deskripsi"
                        value={deskripsi}
                        onChange={(e) => setDeskripsi(e.target.value)}
                        className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold min-h-[120px]"
                        placeholder="Deskripsi singkat tentang menu"
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="tersedia" className="text-batik-brown cursor-pointer">
                        Tersedia untuk dipesan
                      </Label>
                      <Switch id="tersedia" checked={tersedia} onCheckedChange={setTersedia} />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="is-paket" className="text-batik-brown cursor-pointer">
                        Menu Paket
                      </Label>
                      <Switch id="is-paket" checked={isPaket} onCheckedChange={setIsPaket} />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-4 pt-4 border-t border-batik-brown/20">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => router.back()}
                    className="border-batik-brown text-batik-brown hover:bg-batik-brown/10"
                  >
                    Batal
                  </Button>
                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    {isLoading ? "Menyimpan..." : "Simpan Menu"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  )
}

