"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ChevronLeft, Plus, Trash2, Save } from "lucide-react"
import { supabase } from "@/lib/supabase"
import Link from "next/link"
import { toast } from "@/hooks/use-toast"

interface MenuItem {
  id: number
  nama: string
  kategori_id: number
  kategori?: {
    nama: string
  }
}

interface Bahan {
  id: number
  nama: string
  kategori_id: number
  satuan: string
  kategori?: {
    nama: string
  }
}

interface Resep {
  id: number
  menu_id: number
  bahan_id: number
  jumlah: number
  bahan?: Bahan
}

export default function ResepDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const menuId = Number.parseInt(params.id)

  const [menuDetail, setMenuDetail] = useState<MenuItem | null>(null)
  const [resepList, setResepList] = useState<Resep[]>([])
  const [bahanList, setBahanList] = useState<Bahan[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const [selectedBahanId, setSelectedBahanId] = useState<string>("")
  const [jumlah, setJumlah] = useState<number>(1)
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    fetchMenuDetail()
    fetchResep()
    fetchBahan()
  }, [menuId])

  async function fetchMenuDetail() {
    try {
      const { data, error } = await supabase
        .from("menu")
        .select(`
          id, 
          nama, 
          kategori_id,
          kategori:kategori_id(id, nama)
        `)
        .eq("id", menuId)
        .single()

      if (error) {
        throw error
      }

      setMenuDetail(data)
    } catch (error) {
      console.error("Error fetching menu detail:", error)
      toast({
        title: "Gagal memuat detail menu",
        description: "Terjadi kesalahan saat memuat data menu",
        variant: "destructive",
      })
    }
  }

  async function fetchResep() {
    setIsLoading(true)
    try {
      const { data, error } = await supabase
        .from("resep")
        .select(`
          id, 
          menu_id, 
          bahan_id,
          jumlah,
          bahan:bahan_id(
            id, 
            nama, 
            kategori_id, 
            satuan,
            kategori:kategori_id(id, nama)
          )
        `)
        .eq("menu_id", menuId)
        .order("id")

      if (error) {
        throw error
      }

      setResepList(data || [])
    } catch (error) {
      console.error("Error fetching resep:", error)
      toast({
        title: "Gagal memuat data resep",
        description: "Terjadi kesalahan saat memuat resep",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  async function fetchBahan() {
    try {
      const { data, error } = await supabase
        .from("bahan")
        .select(`
          id, 
          nama, 
          kategori_id,
          satuan,
          kategori:kategori_id(id, nama)
        `)
        .order("nama")

      if (error) {
        throw error
      }

      setBahanList(data || [])
    } catch (error) {
      console.error("Error fetching bahan:", error)
      toast({
        title: "Gagal memuat data bahan",
        description: "Terjadi kesalahan saat memuat bahan",
        variant: "destructive",
      })
    }
  }

  async function handleAddResep() {
    setIsSubmitting(true)
    try {
      // Validasi
      if (!selectedBahanId) {
        throw new Error("Bahan harus dipilih")
      }

      if (jumlah <= 0) {
        throw new Error("Jumlah harus lebih dari 0")
      }

      // Cek apakah bahan sudah ada di resep
      const existingResep = resepList.find((r) => r.bahan_id === Number.parseInt(selectedBahanId))

      if (existingResep) {
        throw new Error("Bahan ini sudah ada dalam resep")
      }

      const { data, error } = await supabase
        .from("resep")
        .insert([
          {
            menu_id: menuId,
            bahan_id: Number.parseInt(selectedBahanId),
            jumlah,
          },
        ])
        .select(`
          id, 
          menu_id, 
          bahan_id,
          jumlah,
          bahan:bahan_id(
            id, 
            nama, 
            kategori_id, 
            satuan,
            kategori:kategori_id(id, nama)
          )
        `)

      if (error) {
        throw error
      }

      setResepList([...resepList, ...data])
      setSelectedBahanId("")
      setJumlah(1)
      setIsDialogOpen(false)

      toast({
        title: "Bahan berhasil ditambahkan",
        description: "Bahan telah ditambahkan ke resep",
      })
    } catch (error: any) {
      console.error("Error adding resep:", error)
      toast({
        title: "Gagal menambahkan bahan",
        description: error.message || "Terjadi kesalahan saat menambahkan bahan",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleDeleteResep(resepId: number) {
    try {
      const { error } = await supabase.from("resep").delete().eq("id", resepId)

      if (error) {
        throw error
      }

      setResepList(resepList.filter((r) => r.id !== resepId))

      toast({
        title: "Bahan berhasil dihapus",
        description: "Bahan telah dihapus dari resep",
      })
    } catch (error) {
      console.error("Error deleting resep:", error)
      toast({
        title: "Gagal menghapus bahan",
        description: "Terjadi kesalahan saat menghapus bahan",
        variant: "destructive",
      })
    }
  }

  const availableBahan = bahanList.filter((bahan) => !resepList.some((resep) => resep.bahan_id === bahan.id))

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-8 bg-batik-cream/30">
        <div className="container">
          <div className="flex items-center mb-8">
            <Link href="/pengaturan/resep" className="text-batik-brown hover:text-batik-deepRed mr-4">
              <ChevronLeft className="h-5 w-5" />
            </Link>
            <h1 className="text-3xl font-bold text-batik-brown font-javanese">
              Resep: {menuDetail?.nama || "Loading..."}
            </h1>
          </div>

          <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm mb-6">
            <CardHeader>
              <CardTitle className="text-batik-brown">Detail Menu</CardTitle>
              <CardDescription>Informasi menu dan bahan-bahan yang diperlukan</CardDescription>
            </CardHeader>
            <CardContent>
              {menuDetail ? (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-batik-brown/70">Nama Menu</h3>
                    <p className="font-medium text-batik-brown">{menuDetail.nama}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-batik-brown/70">Kategori</h3>
                    <p className="font-medium text-batik-brown">{menuDetail.kategori?.nama}</p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-4">
                  <div className="inline-block h-6 w-6 animate-spin rounded-full border-4 border-solid border-batik-brown border-r-transparent"></div>
                  <p className="mt-2 text-batik-brown/70">Memuat detail menu...</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-batik-brown">Daftar Bahan</CardTitle>
                <CardDescription>Bahan-bahan yang diperlukan untuk membuat menu ini</CardDescription>
              </div>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
                    <Plus className="h-4 w-4 mr-2" />
                    Tambah Bahan
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-white border-batik-brown/30 sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle className="text-batik-brown">Tambah Bahan</DialogTitle>
                    <DialogDescription>Tambahkan bahan untuk resep menu ini</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="bahan_id" className="text-batik-brown">
                        Pilih Bahan
                      </Label>
                      <Select value={selectedBahanId} onValueChange={setSelectedBahanId}>
                        <SelectTrigger className="bg-white border-batik-brown/30 focus:ring-batik-gold">
                          <SelectValue placeholder="Pilih bahan" />
                        </SelectTrigger>
                        <SelectContent>
                          {availableBahan.length === 0 ? (
                            <SelectItem value="none" disabled>
                              Tidak ada bahan tersedia
                            </SelectItem>
                          ) : (
                            availableBahan.map((bahan) => (
                              <SelectItem key={bahan.id} value={bahan.id.toString()}>
                                {bahan.nama} ({bahan.satuan})
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="jumlah" className="text-batik-brown">
                        Jumlah
                      </Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="jumlah"
                          type="number"
                          min="0.1"
                          step="0.1"
                          value={jumlah}
                          onChange={(e) => setJumlah(Number.parseFloat(e.target.value) || 0)}
                          className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
                        />
                        <span className="text-sm text-batik-brown/70">
                          {selectedBahanId
                            ? bahanList.find((b) => b.id === Number.parseInt(selectedBahanId))?.satuan
                            : "satuan"}
                        </span>
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsDialogOpen(false)}
                      className="border-batik-brown text-batik-brown hover:bg-batik-brown/10"
                    >
                      Batal
                    </Button>
                    <Button
                      onClick={handleAddResep}
                      disabled={isSubmitting || !selectedBahanId || jumlah <= 0}
                      className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Tambahkan
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-10">
                  <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-batik-brown border-r-transparent"></div>
                  <p className="mt-2 text-batik-brown/70">Memuat data resep...</p>
                </div>
              ) : resepList.length === 0 ? (
                <div className="text-center py-10 border border-dashed border-batik-brown/20 rounded-md">
                  <p className="text-batik-brown/70">Belum ada bahan untuk resep ini</p>
                  <Button
                    onClick={() => setIsDialogOpen(true)}
                    className="mt-4 bg-batik-brown hover:bg-batik-darkGreen text-batik-cream"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Tambah Bahan
                  </Button>
                </div>
              ) : (
                <div className="border border-batik-brown/20 rounded-md overflow-hidden">
                  <Table>
                    <TableHeader className="bg-batik-brown/5">
                      <TableRow>
                        <TableHead className="text-batik-brown">Nama Bahan</TableHead>
                        <TableHead className="text-batik-brown">Kategori</TableHead>
                        <TableHead className="text-batik-brown text-center">Jumlah</TableHead>
                        <TableHead className="text-batik-brown text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {resepList.map((resep) => (
                        <TableRow key={resep.id}>
                          <TableCell className="font-medium">{resep.bahan?.nama}</TableCell>
                          <TableCell>{resep.bahan?.kategori?.nama}</TableCell>
                          <TableCell className="text-center">
                            {resep.jumlah} {resep.bahan?.satuan}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteResep(resep.id)}
                              className="h-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Hapus
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  )
}

