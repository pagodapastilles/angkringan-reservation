"use client"

import { useEffect, useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Search, ChefHat } from "lucide-react"
import { supabase } from "@/lib/supabase"
import Link from "next/link"
import { toast } from "@/hooks/use-toast"

interface MenuItem {
  id: number
  nama: string
  kategori_id: number
  is_paket: boolean
  kategori?: {
    nama: string
  }
  bahan_count: number
}

export default function ResepPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [menuItems, setMenuItems] = useState<MenuItem[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchMenuWithResepCount()
  }, [])

  async function fetchMenuWithResepCount() {
    setIsLoading(true)
    try {
      // First fetch all menu items
      const { data: menuData, error: menuError } = await supabase
        .from("menu")
        .select(`
          id, 
          nama, 
          kategori_id,
          is_paket,
          kategori:kategori_id(id, nama)
        `)
        .order("nama")

      if (menuError) {
        throw menuError
      }

      // Get count of bahan for each menu
      const menuWithBahanCount = await Promise.all(
        (menuData || []).map(async (menu) => {
          const { count, error } = await supabase.from("resep").select("id", { count: "exact" }).eq("menu_id", menu.id)

          return {
            ...menu,
            bahan_count: count || 0,
          }
        }),
      )

      setMenuItems(menuWithBahanCount)
    } catch (error) {
      console.error("Error fetching menu items with resep count:", error)
      toast({
        title: "Gagal memuat data",
        description: "Terjadi kesalahan saat memuat data menu dan resep",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Filter menu berdasarkan search term
  const filteredMenu = menuItems.filter((item) => item.nama.toLowerCase().includes(searchTerm.toLowerCase()))

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-8 bg-batik-cream/30">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-batik-brown font-javanese">Manajemen Resep</h1>
            <div className="flex items-center gap-2 mt-4 md:mt-0">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-batik-brown/50" />
                <Input
                  type="search"
                  placeholder="Cari menu..."
                  className="pl-8 bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </div>

          <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-batik-brown">Daftar Menu dan Resep</CardTitle>
              <CardDescription>Kelola resep untuk setiap menu di sini</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-10">
                  <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-batik-brown border-r-transparent"></div>
                  <p className="mt-2 text-batik-brown/70">Memuat data menu dan resep...</p>
                </div>
              ) : filteredMenu.length === 0 ? (
                <div className="text-center py-12 text-batik-brown/50">
                  <p>Tidak ada menu ditemukan</p>
                  <Button asChild className="mt-4 bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
                    <Link href="/pengaturan/menu/tambah">
                      <Plus className="h-4 w-4 mr-2" />
                      Tambah Menu Baru
                    </Link>
                  </Button>
                </div>
              ) : (
                <div className="border border-batik-brown/20 rounded-md overflow-hidden">
                  <Table>
                    <TableHeader className="bg-batik-brown/5">
                      <TableRow>
                        <TableHead className="text-batik-brown">Nama Menu</TableHead>
                        <TableHead className="text-batik-brown">Kategori</TableHead>
                        <TableHead className="text-batik-brown text-center">Jumlah Bahan</TableHead>
                        <TableHead className="text-batik-brown text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredMenu.map((menu) => (
                        <TableRow key={menu.id}>
                          <TableCell className="font-medium">{menu.nama}</TableCell>
                          <TableCell>
                            <span
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                menu.is_paket
                                  ? "bg-purple-100 text-purple-800"
                                  : menu.kategori?.nama === "Makanan"
                                    ? "bg-blue-100 text-blue-800"
                                    : menu.kategori?.nama === "Minuman"
                                      ? "bg-green-100 text-green-800"
                                      : "bg-yellow-100 text-yellow-800"
                              }`}
                            >
                              {menu.is_paket ? "Paket" : menu.kategori?.nama}
                            </span>
                          </TableCell>
                          <TableCell className="text-center">
                            <span className="px-2.5 py-1 bg-batik-brown/10 rounded-md text-batik-brown">
                              {menu.bahan_count}
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button asChild className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
                              <Link href={`/pengaturan/resep/${menu.id}`}>
                                <ChefHat className="h-4 w-4 mr-2" />
                                Kelola Resep
                              </Link>
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  )
}

