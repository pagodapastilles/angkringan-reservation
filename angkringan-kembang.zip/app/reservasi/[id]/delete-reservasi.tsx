"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Trash } from "lucide-react"
import { deleteReservation } from "@/lib/supabase"
import { toast } from "@/hooks/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface DeleteReservasiProps {
  id: number
}

export function DeleteReservasi({ id }: DeleteReservasiProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)

  const handleDelete = async () => {
    setIsLoading(true)

    try {
      await deleteReservation(id)
      toast({
        title: "Reservasi berhasil dihapus",
        description: "Data reservasi telah dihapus dari sistem",
      })
      router.push("/reservasi")
      router.refresh()
    } catch (error) {
      console.error("Error deleting reservation:", error)
      toast({
        title: "Gagal menghapus reservasi",
        description: "Terjadi kesalahan saat menghapus data",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button variant="outline" className="w-full border-destructive text-destructive hover:bg-destructive/10">
          <Trash className="h-4 w-4 mr-2" />
          Hapus Reservasi
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent className="bg-white border-batik-brown/30">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-batik-brown">Konfirmasi Hapus Reservasi</AlertDialogTitle>
          <AlertDialogDescription>
            Apakah Anda yakin ingin menghapus reservasi ini? Tindakan ini tidak dapat dibatalkan.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="border-batik-brown text-batik-brown hover:bg-batik-brown/10">
            Batal
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDelete}
            disabled={isLoading}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {isLoading ? "Menghapus..." : "Hapus"}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

