import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, ChevronLeft, Edit } from "lucide-react"
import Link from "next/link"
import { getReservations, getMenuItems, getKebutuhanTambahan, getFasilitasTambahan } from "@/lib/supabase"
import { notFound } from "next/navigation"
import { DeleteReservasi } from "./delete-reservasi"

export default async function DetailReservasiPage({ params }: { params: { id: string } }) {
  const reservations = await getReservations()
  const reservation = reservations.find((res) => res.id === Number.parseInt(params.id))

  if (!reservation) {
    notFound()
  }

  const menuItems = await getMenuItems()
  const kebutuhanTambahan = await getKebutuhanTambahan()
  const fasilitasTambahan = await getFasilitasTambahan()

  // Filter menu yang dipilih
  const selectedMenus = menuItems.filter((item) => reservation.menu_ids?.includes(item.id))

  // Filter kebutuhan tambahan yang dipilih
  const selectedKebutuhan = kebutuhanTambahan.filter((item) => reservation.kebutuhan_tambahan_ids?.includes(item.id))

  // Filter fasilitas tambahan yang dipilih
  const selectedFasilitas = fasilitasTambahan.filter((item) => reservation.fasilitas_tambahan_ids?.includes(item.id))

  // Hitung total biaya
  const totalMenuCost = selectedMenus.reduce((total, item) => total + (item.harga || 0), 0)
  const totalKebutuhanCost = selectedKebutuhan.reduce((total, item) => total + (item.biaya || 0), 0)
  const totalFasilitasCost = selectedFasilitas.reduce((total, item) => total + (item.biaya || 0), 0)
  const totalCost = totalMenuCost + totalKebutuhanCost + totalFasilitasCost

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-8 bg-batik-cream/30">
        <div className="container">
          <div className="flex items-center mb-8">
            <Link href="/reservasi" className="text-batik-brown hover:text-batik-deepRed mr-4">
              <ChevronLeft className="h-5 w-5" />
            </Link>
            <h1 className="text-3xl font-bold text-batik-brown font-javanese">Detail Reservasi</h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-batik-brown flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-batik-gold" />
                  Informasi Reservasi
                </CardTitle>
                <CardDescription>Detail lengkap reservasi</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium text-batik-brown/70">Nama Pemesan</h3>
                      <p className="text-batik-brown font-medium">{reservation.nama_pemesan}</p>
                    </div>

                    <div>
                      <h3 className="text-sm font-medium text-batik-brown/70">Email</h3>
                      <p className="text-batik-brown">{reservation.email}</p>
                    </div>

                    <div>
                      <h3 className="text-sm font-medium text-batik-brown/70">Nomor Telepon</h3>
                      <p className="text-batik-brown">{reservation.telepon}</p>
                    </div>

                    <div>
                      <h3 className="text-sm font-medium text-batik-brown/70">Tanggal & Waktu</h3>
                      <p className="text-batik-brown">
                        {new Date(reservation.tanggal_reservasi).toLocaleDateString("id-ID", {
                          weekday: "long",
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}{" "}
                        - {reservation.jam_reservasi}
                      </p>
                    </div>

                    <div>
                      <h3 className="text-sm font-medium text-batik-brown/70">Jumlah Tamu</h3>
                      <p className="text-batik-brown">{reservation.jumlah_tamu} orang</p>
                    </div>

                    <div>
                      <h3 className="text-sm font-medium text-batik-brown/70">Status</h3>
                      <p className="text-batik-brown">{reservation.status || "Terkonfirmasi"}</p>
                    </div>

                    {reservation.catatan && (
                      <div>
                        <h3 className="text-sm font-medium text-batik-brown/70">Catatan</h3>
                        <p className="text-batik-brown">{reservation.catatan}</p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium text-batik-brown mb-2">Menu yang Dipilih</h3>
                      {selectedMenus.length > 0 ? (
                        <div className="space-y-2">
                          {selectedMenus.map((item) => (
                            <div
                              key={item.id}
                              className="flex justify-between p-2 border border-batik-brown/20 rounded-md bg-white"
                            >
                              <span>{item.nama}</span>
                              <span className="font-medium">Rp {item.harga?.toLocaleString()}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-batik-brown/50 text-sm">Tidak ada menu yang dipilih</p>
                      )}
                    </div>

                    <div>
                      <h3 className="text-lg font-medium text-batik-brown mb-2">Kebutuhan Tambahan</h3>
                      {selectedKebutuhan.length > 0 ? (
                        <div className="space-y-2">
                          {selectedKebutuhan.map((item) => (
                            <div
                              key={item.id}
                              className="flex justify-between p-2 border border-batik-brown/20 rounded-md bg-white"
                            >
                              <span>{item.nama}</span>
                              <span className="font-medium">Rp {item.biaya?.toLocaleString()}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-batik-brown/50 text-sm">Tidak ada kebutuhan tambahan</p>
                      )}
                    </div>

                    <div>
                      <h3 className="text-lg font-medium text-batik-brown mb-2">Fasilitas Tambahan</h3>
                      {selectedFasilitas.length > 0 ? (
                        <div className="space-y-2">
                          {selectedFasilitas.map((item) => (
                            <div
                              key={item.id}
                              className="flex justify-between p-2 border border-batik-brown/20 rounded-md bg-white"
                            >
                              <span>{item.nama}</span>
                              <span className="font-medium">Rp {item.biaya?.toLocaleString()}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-batik-brown/50 text-sm">Tidak ada fasilitas tambahan</p>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm h-fit">
              <CardHeader>
                <CardTitle className="text-batik-brown">Ringkasan Biaya</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-batik-brown/70">Total Menu</span>
                    <span className="font-medium">Rp {totalMenuCost.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-batik-brown/70">Total Kebutuhan Tambahan</span>
                    <span className="font-medium">Rp {totalKebutuhanCost.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-batik-brown/70">Total Fasilitas Tambahan</span>
                    <span className="font-medium">Rp {totalFasilitasCost.toLocaleString()}</span>
                  </div>
                  <div className="pt-2 mt-2 border-t border-batik-brown/20 flex justify-between">
                    <span className="font-medium">Total Biaya</span>
                    <span className="font-bold text-lg">Rp {totalCost.toLocaleString()}</span>
                  </div>
                </div>

                <div className="mt-6 space-y-3">
                  <Button asChild className="w-full bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
                    <Link href={`/reservasi/${params.id}/edit`}>
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Reservasi
                    </Link>
                  </Button>
                  <DeleteReservasi id={Number.parseInt(params.id)} />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

