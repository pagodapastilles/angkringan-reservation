import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Plus, Search } from "lucide-react"
import Link from "next/link"
import { getReservations } from "@/lib/supabase"
import { Input } from "@/components/ui/input"

export default async function ReservasiPage() {
  const reservations = await getReservations()

  // Dapatkan tanggal hari ini
  const today = new Date().toISOString().split("T")[0]

  // Filter reservasi berdasarkan tanggal
  const reservasiHariIni = reservations.filter((res) => res.tanggal_reservasi === today)
  const reservasiMendatang = reservations.filter((res) => res.tanggal_reservasi > today)
  const reservasiLampau = reservations.filter((res) => res.tanggal_reservasi < today)

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-8 bg-batik-cream/30">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-batik-brown font-javanese">Reservasi</h1>
            <div className="flex items-center gap-2 mt-4 md:mt-0">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-batik-brown/50" />
                <Input
                  type="search"
                  placeholder="Cari reservasi..."
                  className="pl-8 bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
                />
              </div>
              <Button asChild className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
                <Link href="/reservasi/tambah">
                  <Plus className="h-4 w-4 mr-2" />
                  Tambah Reservasi
                </Link>
              </Button>
            </div>
          </div>

          <Tabs defaultValue="hari-ini" className="w-full">
            <TabsList className="mb-6 bg-white/50 border border-batik-brown/20">
              <TabsTrigger
                value="hari-ini"
                className="data-[state=active]:bg-batik-brown data-[state=active]:text-batik-cream"
              >
                Hari Ini ({reservasiHariIni.length})
              </TabsTrigger>
              <TabsTrigger
                value="mendatang"
                className="data-[state=active]:bg-batik-brown data-[state=active]:text-batik-cream"
              >
                Mendatang ({reservasiMendatang.length})
              </TabsTrigger>
              <TabsTrigger
                value="lampau"
                className="data-[state=active]:bg-batik-brown data-[state=active]:text-batik-cream"
              >
                Lampau ({reservasiLampau.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="hari-ini">
              <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-batik-brown flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-batik-gold" />
                    Reservasi Hari Ini
                  </CardTitle>
                  <CardDescription>
                    {new Date().toLocaleDateString("id-ID", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {reservasiHariIni.length > 0 ? (
                    <div className="space-y-4">
                      {reservasiHariIni.map((reservation) => (
                        <div
                          key={reservation.id}
                          className="flex justify-between items-center p-4 border border-batik-brown/20 rounded-md bg-white hover:border-batik-brown/50 transition-colors"
                        >
                          <div>
                            <h3 className="font-medium text-batik-brown">{reservation.nama_pemesan}</h3>
                            <p className="text-sm text-batik-brown/70">
                              {reservation.jam_reservasi} - {reservation.jumlah_tamu} orang
                            </p>
                            <p className="text-sm text-batik-brown/70">{reservation.status || "Terkonfirmasi"}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Link
                              href={`/reservasi/${reservation.id}`}
                              className="text-xs px-3 py-1 bg-batik-brown text-batik-cream rounded-full hover:bg-batik-darkGreen transition-colors"
                            >
                              Detail
                            </Link>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 text-batik-brown/50">
                      <Calendar className="h-12 w-12 mx-auto mb-4 opacity-30" />
                      <p>Tidak ada reservasi untuk hari ini</p>
                      <Button asChild className="mt-4 bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
                        <Link href="/reservasi/tambah">
                          <Plus className="h-4 w-4 mr-2" />
                          Tambah Reservasi
                        </Link>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="mendatang">
              <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-batik-brown flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-batik-gold" />
                    Reservasi Mendatang
                  </CardTitle>
                  <CardDescription>Daftar reservasi yang akan datang</CardDescription>
                </CardHeader>
                <CardContent>
                  {reservasiMendatang.length > 0 ? (
                    <div className="space-y-4">
                      {reservasiMendatang.map((reservation) => (
                        <div
                          key={reservation.id}
                          className="flex justify-between items-center p-4 border border-batik-brown/20 rounded-md bg-white hover:border-batik-brown/50 transition-colors"
                        >
                          <div>
                            <h3 className="font-medium text-batik-brown">{reservation.nama_pemesan}</h3>
                            <p className="text-sm text-batik-brown/70">
                              {new Date(reservation.tanggal_reservasi).toLocaleDateString("id-ID")} -{" "}
                              {reservation.jam_reservasi}
                            </p>
                            <p className="text-sm text-batik-brown/70">
                              {reservation.jumlah_tamu} orang - {reservation.status || "Terkonfirmasi"}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Link
                              href={`/reservasi/${reservation.id}`}
                              className="text-xs px-3 py-1 bg-batik-brown text-batik-cream rounded-full hover:bg-batik-darkGreen transition-colors"
                            >
                              Detail
                            </Link>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 text-batik-brown/50">
                      <Calendar className="h-12 w-12 mx-auto mb-4 opacity-30" />
                      <p>Tidak ada reservasi mendatang</p>
                      <Button asChild className="mt-4 bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
                        <Link href="/reservasi/tambah">
                          <Plus className="h-4 w-4 mr-2" />
                          Tambah Reservasi
                        </Link>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="lampau">
              <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-batik-brown flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-batik-gold" />
                    Reservasi Lampau
                  </CardTitle>
                  <CardDescription>Daftar reservasi yang sudah lewat</CardDescription>
                </CardHeader>
                <CardContent>
                  {reservasiLampau.length > 0 ? (
                    <div className="space-y-4">
                      {reservasiLampau.map((reservation) => (
                        <div
                          key={reservation.id}
                          className="flex justify-between items-center p-4 border border-batik-brown/20 rounded-md bg-white hover:border-batik-brown/50 transition-colors"
                        >
                          <div>
                            <h3 className="font-medium text-batik-brown">{reservation.nama_pemesan}</h3>
                            <p className="text-sm text-batik-brown/70">
                              {new Date(reservation.tanggal_reservasi).toLocaleDateString("id-ID")} -{" "}
                              {reservation.jam_reservasi}
                            </p>
                            <p className="text-sm text-batik-brown/70">
                              {reservation.jumlah_tamu} orang - {reservation.status || "Selesai"}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Link
                              href={`/reservasi/${reservation.id}`}
                              className="text-xs px-3 py-1 bg-batik-brown text-batik-cream rounded-full hover:bg-batik-darkGreen transition-colors"
                            >
                              Detail
                            </Link>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 text-batik-brown/50">
                      <Calendar className="h-12 w-12 mx-auto mb-4 opacity-30" />
                      <p>Tidak ada riwayat reservasi</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  )
}

