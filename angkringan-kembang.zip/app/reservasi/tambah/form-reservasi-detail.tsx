"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Trash2, Calendar, Clock, User, DollarSign, Utensils, Coffee, Music, FileText } from "lucide-react"
import { addReservation } from "@/lib/supabase"
import { toast } from "@/hooks/use-toast"
import type { MenuItem, FasilitasTambahan, MetodePembayaran, StatusPembayaran } from "@/lib/types"

interface FormReservasiDetailProps {
  makanan: MenuItem[]
  minuman: MenuItem[]
  fasilitasTambahan: FasilitasTambahan[]
}

interface PesananItem {
  menu_id: number
  nama: string
  harga: number
  jumlah: number
  kategori: "makanan" | "minuman"
  catatan?: string
}

export function FormReservasiDetail({ makanan, minuman, fasilitasTambahan }: FormReservasiDetailProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)

  // State untuk informasi dasar
  const [nama, setNama] = useState("")
  const [telepon, setTelepon] = useState("")
  const [jumlahOrang, setJumlahOrang] = useState(1)

  // State untuk tanggal dan waktu
  const [tanggal, setTanggal] = useState("")
  const [waktu, setWaktu] = useState("")
  const [nomorMeja, setNomorMeja] = useState<number | undefined>()

  // State untuk pesanan
  const [pesanan, setPesanan] = useState<PesananItem[]>([])
  const [selectedMenuId, setSelectedMenuId] = useState<number | null>(null)
  const [selectedMenuJumlah, setSelectedMenuJumlah] = useState(1)
  const [catatanPesanan, setCatatanPesanan] = useState("")

  // State untuk fasilitas tambahan
  const [selectedFasilitas, setSelectedFasilitas] = useState<number[]>([])

  // State untuk pembayaran
  const [statusPembayaran, setStatusPembayaran] = useState<StatusPembayaran>("belum_dp")
  const [metodePembayaran, setMetodePembayaran] = useState<MetodePembayaran | undefined>()
  const [nominalDp, setNominalDp] = useState<number | undefined>()

  // State untuk catatan
  const [catatan, setCatatan] = useState("")

  // State untuk dialog tambah pesanan
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [dialogTab, setDialogTab] = useState("makanan")

  // Hitung total biaya
  const totalPesanan = pesanan.reduce((total, item) => total + item.harga * item.jumlah, 0)

  const totalFasilitas = selectedFasilitas.reduce((total, fasilitasId) => {
    const fasilitas = fasilitasTambahan.find((f) => f.id === fasilitasId)
    return total + (fasilitas?.biaya || 0)
  }, 0)

  const totalBiaya = totalPesanan + totalFasilitas
  const sisaPembayaran = totalBiaya - (nominalDp || 0)

  // Fungsi untuk menambahkan pesanan
  const handleAddPesanan = () => {
    if (!selectedMenuId) return

    const menuList = [...makanan, ...minuman]
    const selectedMenu = menuList.find((menu) => menu.id === selectedMenuId)

    if (!selectedMenu) return

    const newItem: PesananItem = {
      menu_id: selectedMenu.id,
      nama: selectedMenu.nama,
      harga: selectedMenu.harga,
      jumlah: selectedMenuJumlah,
      kategori: selectedMenu.kategori,
      catatan: catatanPesanan || undefined,
    }

    setPesanan([...pesanan, newItem])
    setSelectedMenuId(null)
    setSelectedMenuJumlah(1)
    setCatatanPesanan("")
    setIsDialogOpen(false)
  }

  // Fungsi untuk menghapus pesanan
  const handleRemovePesanan = (index: number) => {
    const newPesanan = [...pesanan]
    newPesanan.splice(index, 1)
    setPesanan(newPesanan)
  }

  // Fungsi untuk toggle fasilitas tambahan
  const toggleFasilitas = (id: number) => {
    setSelectedFasilitas((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]))
  }

  // Fungsi untuk submit form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Get the authenticated admin
      const admin = JSON.parse(localStorage.getItem("admin") || "{}")

      // Data reservasi
      const reservationData = {
        nama_pemesan: nama,
        telepon,
        jumlah_orang: jumlahOrang,
        tanggal_reservasi: tanggal,
        waktu_reservasi: waktu,
        nomor_meja: nomorMeja,
        catatan,
        status_pembayaran: statusPembayaran,
        metode_pembayaran: metodePembayaran,
        nominal_dp: nominalDp,
        total_biaya: totalBiaya,
        fasilitas_tambahan_ids: selectedFasilitas,
        admin_id: admin.id || 1, // Use the authenticated admin ID or default to 1
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }

      // Data item pesanan
      const itemPesanan = pesanan.map((item) => ({
        menu_id: item.menu_id,
        jumlah: item.jumlah,
        catatan: item.catatan,
      }))

      await addReservation(reservationData, itemPesanan)

      toast({
        title: "Reservasi berhasil ditambahkan",
        description: "Data reservasi telah disimpan",
      })

      router.push("/reservasi")
      router.refresh()
    } catch (error) {
      console.error("Error adding reservation:", error)
      toast({
        title: "Gagal menambahkan reservasi",
        description: "Terjadi kesalahan saat menyimpan data",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Dapatkan waktu saat ini untuk informasi admin
  const currentDate = new Date().toLocaleDateString("id-ID", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  const currentTime = new Date().toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
  })

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Bagian 1: Informasi Dasar */}
      <Card className="border-batik-brown/20 bg-white">
        <CardHeader className="bg-batik-brown/5 border-b border-batik-brown/10 pb-3">
          <CardTitle className="text-batik-brown text-lg flex items-center gap-2">
            <User className="h-5 w-5 text-batik-gold" />
            Informasi Pemesan
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <Label htmlFor="nama" className="text-batik-brown">
                Nama Pemesan <span className="text-red-500">*</span>
              </Label>
              <Input
                id="nama"
                value={nama}
                onChange={(e) => setNama(e.target.value)}
                required
                className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold mt-1.5"
                placeholder="Masukkan nama pemesan"
              />
            </div>

            <div>
              <Label htmlFor="telepon" className="text-batik-brown">
                Nomor Telepon <span className="text-red-500">*</span>
              </Label>
              <Input
                id="telepon"
                value={telepon}
                onChange={(e) => setTelepon(e.target.value)}
                required
                className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold mt-1.5"
                placeholder="Contoh: 08123456789"
              />
            </div>

            <div>
              <Label htmlFor="jumlah_orang" className="text-batik-brown">
                Jumlah Orang <span className="text-red-500">*</span>
              </Label>
              <div className="flex items-center mt-1.5">
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="h-10 w-10 rounded-r-none border-batik-brown/30"
                  onClick={() => setJumlahOrang((prev) => Math.max(1, prev - 1))}
                >
                  -
                </Button>
                <Input
                  id="jumlah_orang"
                  type="number"
                  min="1"
                  value={jumlahOrang}
                  onChange={(e) => setJumlahOrang(Number.parseInt(e.target.value) || 1)}
                  required
                  className="h-10 rounded-none text-center border-x-0 border-batik-brown/30"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="h-10 w-10 rounded-l-none border-batik-brown/30"
                  onClick={() => setJumlahOrang((prev) => prev + 1)}
                >
                  +
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bagian 2: Tanggal dan Waktu */}
      <Card className="border-batik-brown/20 bg-white">
        <CardHeader className="bg-batik-brown/5 border-b border-batik-brown/10 pb-3">
          <CardTitle className="text-batik-brown text-lg flex items-center gap-2">
            <Calendar className="h-5 w-5 text-batik-gold" />
            Tanggal dan Waktu
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <Label htmlFor="tanggal" className="text-batik-brown">
                Tanggal Reservasi <span className="text-red-500">*</span>
              </Label>
              <div className="relative mt-1.5">
                <Calendar className="absolute left-3 top-3 h-4 w-4 text-batik-brown/50" />
                <Input
                  id="tanggal"
                  type="date"
                  value={tanggal}
                  onChange={(e) => setTanggal(e.target.value)}
                  required
                  className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold pl-10"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="waktu" className="text-batik-brown">
                Waktu Reservasi <span className="text-red-500">*</span>
              </Label>
              <div className="relative mt-1.5">
                <Clock className="absolute left-3 top-3 h-4 w-4 text-batik-brown/50" />
                <Select value={waktu} onValueChange={setWaktu} required>
                  <SelectTrigger className="bg-white border-batik-brown/30 focus:ring-batik-gold pl-10">
                    <SelectValue placeholder="Pilih waktu" />
                  </SelectTrigger>
                  <SelectContent>
                    {[
                      "10:00",
                      "10:30",
                      "11:00",
                      "11:30",
                      "12:00",
                      "12:30",
                      "13:00",
                      "13:30",
                      "14:00",
                      "14:30",
                      "15:00",
                      "15:30",
                      "16:00",
                      "16:30",
                      "17:00",
                      "17:30",
                      "18:00",
                      "18:30",
                      "19:00",
                      "19:30",
                      "20:00",
                      "20:30",
                      "21:00",
                    ].map((time) => (
                      <SelectItem key={time} value={time}>
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="nomor_meja" className="text-batik-brown">
                Nomor Meja
              </Label>
              <Input
                id="nomor_meja"
                type="number"
                min="1"
                value={nomorMeja || ""}
                onChange={(e) => setNomorMeja(Number.parseInt(e.target.value) || undefined)}
                className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold mt-1.5"
                placeholder="Opsional"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bagian 3: Pesanan */}
      <Card className="border-batik-brown/20 bg-white">
        <CardHeader className="bg-batik-brown/5 border-b border-batik-brown/10 pb-3">
          <div className="flex justify-between items-center">
            <CardTitle className="text-batik-brown text-lg flex items-center gap-2">
              <Utensils className="h-5 w-5 text-batik-gold" />
              Pesanan
            </CardTitle>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button type="button" className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
                  <Plus className="h-4 w-4 mr-2" />
                  Tambah Pesanan
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-white border-batik-brown/30 sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle className="text-batik-brown">Tambah Pesanan</DialogTitle>
                  <DialogDescription>Pilih menu dan masukkan jumlah pesanan</DialogDescription>
                </DialogHeader>

                <Tabs defaultValue="makanan" value={dialogTab} onValueChange={setDialogTab}>
                  <TabsList className="bg-batik-brown/10 border border-batik-brown/20">
                    <TabsTrigger
                      value="makanan"
                      className="data-[state=active]:bg-batik-brown data-[state=active]:text-batik-cream"
                    >
                      <Utensils className="h-4 w-4 mr-2" />
                      Makanan
                    </TabsTrigger>
                    <TabsTrigger
                      value="minuman"
                      className="data-[state=active]:bg-batik-brown data-[state=active]:text-batik-cream"
                    >
                      <Coffee className="h-4 w-4 mr-2" />
                      Minuman
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="makanan" className="mt-4">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="menu_makanan" className="text-batik-brown">
                          Pilih Menu Makanan
                        </Label>
                        <Select
                          value={selectedMenuId?.toString() || ""}
                          onValueChange={(value) => setSelectedMenuId(Number.parseInt(value))}
                        >
                          <SelectTrigger className="bg-white border-batik-brown/30 focus:ring-batik-gold mt-1.5">
                            <SelectValue placeholder="Pilih menu makanan" />
                          </SelectTrigger>
                          <SelectContent>
                            {makanan.map((item) => (
                              <SelectItem key={item.id} value={item.id.toString()}>
                                {item.nama} - Rp {item.harga.toLocaleString()}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="jumlah_pesanan" className="text-batik-brown">
                          Jumlah
                        </Label>
                        <div className="flex items-center mt-1.5">
                          <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            className="h-10 w-10 rounded-r-none border-batik-brown/30"
                            onClick={() => setSelectedMenuJumlah((prev) => Math.max(1, prev - 1))}
                          >
                            -
                          </Button>
                          <Input
                            id="jumlah_pesanan"
                            type="number"
                            min="1"
                            value={selectedMenuJumlah}
                            onChange={(e) => setSelectedMenuJumlah(Number.parseInt(e.target.value) || 1)}
                            className="h-10 rounded-none text-center border-x-0 border-batik-brown/30"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            className="h-10 w-10 rounded-l-none border-batik-brown/30"
                            onClick={() => setSelectedMenuJumlah((prev) => prev + 1)}
                          >
                            +
                          </Button>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="catatan_pesanan" className="text-batik-brown">
                          Catatan Khusus
                        </Label>
                        <Textarea
                          id="catatan_pesanan"
                          value={catatanPesanan}
                          onChange={(e) => setCatatanPesanan(e.target.value)}
                          className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold mt-1.5"
                          placeholder="Contoh: Tidak pedas, tanpa bawang, dll"
                        />
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="minuman" className="mt-4">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="menu_minuman" className="text-batik-brown">
                          Pilih Menu Minuman
                        </Label>
                        <Select
                          value={selectedMenuId?.toString() || ""}
                          onValueChange={(value) => setSelectedMenuId(Number.parseInt(value))}
                        >
                          <SelectTrigger className="bg-white border-batik-brown/30 focus:ring-batik-gold mt-1.5">
                            <SelectValue placeholder="Pilih menu minuman" />
                          </SelectTrigger>
                          <SelectContent>
                            {minuman.map((item) => (
                              <SelectItem key={item.id} value={item.id.toString()}>
                                {item.nama} - Rp {item.harga.toLocaleString()}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="jumlah_pesanan" className="text-batik-brown">
                          Jumlah
                        </Label>
                        <div className="flex items-center mt-1.5">
                          <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            className="h-10 w-10 rounded-r-none border-batik-brown/30"
                            onClick={() => setSelectedMenuJumlah((prev) => Math.max(1, prev - 1))}
                          >
                            -
                          </Button>
                          <Input
                            id="jumlah_pesanan"
                            type="number"
                            min="1"
                            value={selectedMenuJumlah}
                            onChange={(e) => setSelectedMenuJumlah(Number.parseInt(e.target.value) || 1)}
                            className="h-10 rounded-none text-center border-x-0 border-batik-brown/30"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            className="h-10 w-10 rounded-l-none border-batik-brown/30"
                            onClick={() => setSelectedMenuJumlah((prev) => prev + 1)}
                          >
                            +
                          </Button>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="catatan_pesanan" className="text-batik-brown">
                          Catatan Khusus
                        </Label>
                        <Textarea
                          id="catatan_pesanan"
                          value={catatanPesanan}
                          onChange={(e) => setCatatanPesanan(e.target.value)}
                          className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold mt-1.5"
                          placeholder="Contoh: Tidak pakai es, kurang manis, dll"
                        />
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>

                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsDialogOpen(false)}
                    className="border-batik-brown text-batik-brown hover:bg-batik-brown/10"
                  >
                    Batal
                  </Button>
                  <Button
                    type="button"
                    onClick={handleAddPesanan}
                    disabled={!selectedMenuId}
                    className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream"
                  >
                    Tambahkan
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-6">
            <div>
              <h3 className="text-batik-brown font-medium mb-3 flex items-center gap-2">
                <Utensils className="h-4 w-4 text-batik-gold" />
                Makanan
              </h3>
              {pesanan.filter((item) => item.kategori === "makanan").length > 0 ? (
                <Table>
                  <TableHeader className="bg-batik-brown/5">
                    <TableRow>
                      <TableHead className="w-[50px] text-batik-brown">No</TableHead>
                      <TableHead className="text-batik-brown">Menu</TableHead>
                      <TableHead className="text-batik-brown text-right">Harga</TableHead>
                      <TableHead className="text-batik-brown text-center">Jumlah</TableHead>
                      <TableHead className="text-batik-brown text-right">Subtotal</TableHead>
                      <TableHead className="text-batik-brown w-[100px] text-center">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pesanan
                      .filter((item) => item.kategori === "makanan")
                      .map((item, index) => (
                        <TableRow key={`makanan-${index}`}>
                          <TableCell className="font-medium">{index + 1}</TableCell>
                          <TableCell>
                            {item.nama}
                            {item.catatan && (
                              <p className="text-xs text-batik-brown/60 mt-1">Catatan: {item.catatan}</p>
                            )}
                          </TableCell>
                          <TableCell className="text-right">Rp {item.harga.toLocaleString()}</TableCell>
                          <TableCell className="text-center">{item.jumlah}</TableCell>
                          <TableCell className="text-right font-medium">
                            Rp {(item.harga * item.jumlah).toLocaleString()}
                          </TableCell>
                          <TableCell className="text-center">
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              onClick={() => handleRemovePesanan(pesanan.indexOf(item))}
                              className="h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-6 border border-dashed border-batik-brown/20 rounded-md bg-batik-brown/5">
                  <p className="text-batik-brown/60">Belum ada pesanan makanan</p>
                </div>
              )}
            </div>

            <div>
              <h3 className="text-batik-brown font-medium mb-3 flex items-center gap-2">
                <Coffee className="h-4 w-4 text-batik-gold" />
                Minuman
              </h3>
              {pesanan.filter((item) => item.kategori === "minuman").length > 0 ? (
                <Table>
                  <TableHeader className="bg-batik-brown/5">
                    <TableRow>
                      <TableHead className="w-[50px] text-batik-brown">No</TableHead>
                      <TableHead className="text-batik-brown">Menu</TableHead>
                      <TableHead className="text-batik-brown text-right">Harga</TableHead>
                      <TableHead className="text-batik-brown text-center">Jumlah</TableHead>
                      <TableHead className="text-batik-brown text-right">Subtotal</TableHead>
                      <TableHead className="text-batik-brown w-[100px] text-center">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pesanan
                      .filter((item) => item.kategori === "minuman")
                      .map((item, index) => (
                        <TableRow key={`minuman-${index}`}>
                          <TableCell className="font-medium">{index + 1}</TableCell>
                          <TableCell>
                            {item.nama}
                            {item.catatan && (
                              <p className="text-xs text-batik-brown/60 mt-1">Catatan: {item.catatan}</p>
                            )}
                          </TableCell>
                          <TableCell className="text-right">Rp {item.harga.toLocaleString()}</TableCell>
                          <TableCell className="text-center">{item.jumlah}</TableCell>
                          <TableCell className="text-right font-medium">
                            Rp {(item.harga * item.jumlah).toLocaleString()}
                          </TableCell>
                          <TableCell className="text-center">
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              onClick={() => handleRemovePesanan(pesanan.indexOf(item))}
                              className="h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-6 border border-dashed border-batik-brown/20 rounded-md bg-batik-brown/5">
                  <p className="text-batik-brown/60">Belum ada pesanan minuman</p>
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="catatan" className="text-batik-brown">
                Catatan Khusus untuk Pesanan
              </Label>
              <Textarea
                id="catatan"
                value={catatan}
                onChange={(e) => setCatatan(e.target.value)}
                className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold mt-1.5"
                placeholder="Masukkan catatan khusus untuk seluruh pesanan jika ada"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bagian 4: Fasilitas Tambahan */}
      <Card className="border-batik-brown/20 bg-white">
        <CardHeader className="bg-batik-brown/5 border-b border-batik-brown/10 pb-3">
          <CardTitle className="text-batik-brown text-lg flex items-center gap-2">
            <Music className="h-5 w-5 text-batik-gold" />
            Fasilitas Tambahan
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {fasilitasTambahan.map((fasilitas) => (
              <div
                key={fasilitas.id}
                className={`flex items-start space-x-3 p-3 rounded-md border ${
                  selectedFasilitas.includes(fasilitas.id)
                    ? "border-batik-brown bg-batik-brown/5"
                    : "border-batik-brown/20 bg-white"
                }`}
              >
                <Checkbox
                  id={`fasilitas-${fasilitas.id}`}
                  checked={selectedFasilitas.includes(fasilitas.id)}
                  onCheckedChange={() => toggleFasilitas(fasilitas.id)}
                  className="border-batik-brown/50 data-[state=checked]:bg-batik-brown data-[state=checked]:border-batik-brown mt-0.5"
                />
                <div>
                  <Label htmlFor={`fasilitas-${fasilitas.id}`} className="text-batik-brown font-medium cursor-pointer">
                    {fasilitas.nama}
                  </Label>
                  {fasilitas.biaya > 0 && (
                    <p className="text-sm text-batik-brown/70">Rp {fasilitas.biaya.toLocaleString()}</p>
                  )}
                  {fasilitas.deskripsi && <p className="text-xs text-batik-brown/60 mt-1">{fasilitas.deskripsi}</p>}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Bagian 5: Pembayaran */}
      <Card className="border-batik-brown/20 bg-white">
        <CardHeader className="bg-batik-brown/5 border-b border-batik-brown/10 pb-3">
          <CardTitle className="text-batik-brown text-lg flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-batik-gold" />
            Pembayaran
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <h3 className="text-batik-brown font-medium mb-4">Rincian Biaya</h3>
              <div className="space-y-3 mb-6">
                <div className="flex justify-between pb-2 border-b border-batik-brown/10">
                  <span className="text-batik-brown/70">Total Pesanan</span>
                  <span className="font-medium">Rp {totalPesanan.toLocaleString()}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-batik-brown/10">
                  <span className="text-batik-brown/70">Total Fasilitas Tambahan</span>
                  <span className="font-medium">Rp {totalFasilitas.toLocaleString()}</span>
                </div>
                <div className="flex justify-between pt-2 text-lg">
                  <span className="font-medium text-batik-brown">Total Biaya</span>
                  <span className="font-bold text-batik-brown">Rp {totalBiaya.toLocaleString()}</span>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="status_pembayaran" className="text-batik-brown">
                    Status Pembayaran
                  </Label>
                  <Select
                    value={statusPembayaran}
                    onValueChange={(value) => setStatusPembayaran(value as StatusPembayaran)}
                  >
                    <SelectTrigger className="bg-white border-batik-brown/30 focus:ring-batik-gold mt-1.5">
                      <SelectValue placeholder="Pilih status pembayaran" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="belum_dp">Belum DP</SelectItem>
                      <SelectItem value="sudah_dp">Sudah DP</SelectItem>
                      <SelectItem value="lunas">Lunas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {(statusPembayaran === "sudah_dp" || statusPembayaran === "lunas") && (
                  <>
                    <div>
                      <Label htmlFor="metode_pembayaran" className="text-batik-brown">
                        Metode Pembayaran
                      </Label>
                      <Select
                        value={metodePembayaran}
                        onValueChange={(value) => setMetodePembayaran(value as MetodePembayaran)}
                      >
                        <SelectTrigger className="bg-white border-batik-brown/30 focus:ring-batik-gold mt-1.5">
                          <SelectValue placeholder="Pilih metode pembayaran" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="transfer_bca">Transfer BCA</SelectItem>
                          <SelectItem value="transfer_mandiri">Transfer Mandiri</SelectItem>
                          <SelectItem value="debit_bca">Debit BCA</SelectItem>
                          <SelectItem value="qris_bca">QRIS BCA</SelectItem>
                          <SelectItem value="qris_bri">QRIS BRI</SelectItem>
                          <SelectItem value="cash">Cash</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {statusPembayaran === "sudah_dp" && (
                      <div>
                        <Label htmlFor="nominal_dp" className="text-batik-brown">
                          Nominal DP
                        </Label>
                        <div className="relative mt-1.5">
                          <DollarSign className="absolute left-3 top-3 h-4 w-4 text-batik-brown/50" />
                          <Input
                            id="nominal_dp"
                            type="number"
                            min="0"
                            max={totalBiaya}
                            value={nominalDp || ""}
                            onChange={(e) => setNominalDp(Number.parseInt(e.target.value) || undefined)}
                            className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold pl-10"
                            placeholder="Masukkan nominal DP"
                          />
                        </div>

                        {nominalDp !== undefined && nominalDp > 0 && (
                          <div className="mt-3 p-3 bg-batik-brown/5 border border-batik-brown/20 rounded-md">
                            <div className="flex justify-between">
                              <span className="text-batik-brown/70">Sisa Pembayaran</span>
                              <span className="font-medium text-batik-brown">Rp {sisaPembayaran.toLocaleString()}</span>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>

            <div className="border-t lg:border-t-0 lg:border-l border-batik-brown/10 pt-6 lg:pt-0 lg:pl-8">
              <h3 className="text-batik-brown font-medium mb-4">Informasi Admin</h3>
              <div className="p-4 bg-batik-brown/5 border border-batik-brown/20 rounded-md">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 rounded-full bg-batik-brown/20 flex items-center justify-center mr-3">
                    <User className="h-5 w-5 text-batik-brown" />
                  </div>
                  <div>
                    <p className="font-medium text-batik-brown">Admin Angkringan</p>
                    <p className="text-sm text-batik-brown/70">admin@angkringankembang.com</p>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex">
                    <Calendar className="h-4 w-4 text-batik-gold mr-2" />
                    <span className="text-batik-brown/70">Tanggal Input:</span>
                    <span className="text-batik-brown ml-auto">{currentDate}</span>
                  </div>
                  <div className="flex">
                    <Clock className="h-4 w-4 text-batik-gold mr-2" />
                    <span className="text-batik-brown/70">Waktu Input:</span>
                    <span className="text-batik-brown ml-auto">{currentTime} WIB</span>
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <FileText className="h-5 w-5 text-batik-gold mb-2" />
                <p className="text-sm text-batik-brown/70 mb-2">Catatan:</p>
                <ul className="text-sm text-batik-brown/70 list-disc pl-5 space-y-1">
                  <li>Pastikan semua data reservasi sudah benar sebelum menyimpan</li>
                  <li>Untuk pembatalan reservasi, hubungi manager</li>
                  <li>Reservasi yang sudah dikonfirmasi tidak dapat diubah tanpa persetujuan manager</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tombol Submit */}
      <div className="flex justify-end gap-4 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={() => router.back()}
          className="border-batik-brown text-batik-brown hover:bg-batik-brown/10"
        >
          Batal
        </Button>
        <Button
          type="submit"
          disabled={isLoading || pesanan.length === 0}
          className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream"
        >
          {isLoading ? "Menyimpan..." : "Simpan Reservasi"}
        </Button>
      </div>
    </form>
  )
}

