"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { addReservation } from "@/lib/supabase"
import { toast } from "@/hooks/use-toast"

interface FormReservasiProps {
  menuItems: any[]
  kebutuhanTambahan: any[]
  fasilitasTambahan: any[]
}

export function FormReservasi({ menuItems, kebutuhanTambahan, fasilitasTambahan }: FormReservasiProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    nama_pemesan: "",
    email: "",
    telepon: "",
    tanggal_reservasi: "",
    jam_reservasi: "",
    jumlah_tamu: 1,
    catatan: "",
    menu_ids: [] as number[],
    kebutuhan_tambahan_ids: [] as number[],
    fasilitas_tambahan_ids: [] as number[],
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: Number.parseInt(value) || 0 }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (name: string, id: number, checked: boolean) => {
    setFormData((prev) => {
      const currentIds = prev[name as keyof typeof prev] as number[]
      if (checked) {
        return { ...prev, [name]: [...currentIds, id] }
      } else {
        return { ...prev, [name]: currentIds.filter((item) => item !== id) }
      }
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      await addReservation(formData)
      toast({
        title: "Reservasi berhasil ditambahkan",
        description: "Data reservasi telah disimpan",
      })
      router.push("/reservasi")
      router.refresh()
    } catch (error) {
      console.error("Error adding reservation:", error)
      toast({
        title: "Gagal menambahkan reservasi",
        description: "Terjadi kesalahan saat menyimpan data",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <Label htmlFor="nama_pemesan">Nama Pemesan</Label>
            <Input
              id="nama_pemesan"
              name="nama_pemesan"
              value={formData.nama_pemesan}
              onChange={handleChange}
              required
              className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
            />
          </div>

          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              required
              className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
            />
          </div>

          <div>
            <Label htmlFor="telepon">Nomor Telepon</Label>
            <Input
              id="telepon"
              name="telepon"
              value={formData.telepon}
              onChange={handleChange}
              required
              className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
            />
          </div>

          <div>
            <Label htmlFor="tanggal_reservasi">Tanggal Reservasi</Label>
            <Input
              id="tanggal_reservasi"
              name="tanggal_reservasi"
              type="date"
              value={formData.tanggal_reservasi}
              onChange={handleChange}
              required
              className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
            />
          </div>

          <div>
            <Label htmlFor="jam_reservasi">Jam Reservasi</Label>
            <Select onValueChange={(value) => handleSelectChange("jam_reservasi", value)} required>
              <SelectTrigger className="bg-white border-batik-brown/30 focus:ring-batik-gold">
                <SelectValue placeholder="Pilih jam" />
              </SelectTrigger>
              <SelectContent>
                {[
                  "10:00",
                  "11:00",
                  "12:00",
                  "13:00",
                  "14:00",
                  "15:00",
                  "16:00",
                  "17:00",
                  "18:00",
                  "19:00",
                  "20:00",
                ].map((time) => (
                  <SelectItem key={time} value={time}>
                    {time}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="jumlah_tamu">Jumlah Tamu</Label>
            <Input
              id="jumlah_tamu"
              name="jumlah_tamu"
              type="number"
              min="1"
              value={formData.jumlah_tamu}
              onChange={handleNumberChange}
              required
              className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
            />
          </div>

          <div>
            <Label htmlFor="catatan">Catatan Tambahan</Label>
            <Textarea
              id="catatan"
              name="catatan"
              value={formData.catatan}
              onChange={handleChange}
              className="bg-white border-batik-brown/30 focus-visible:ring-batik-gold"
              rows={4}
            />
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium text-batik-brown mb-3">Pilihan Menu</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[200px] overflow-y-auto p-2 border border-batik-brown/20 rounded-md bg-white">
              {menuItems.map((item) => (
                <div key={item.id} className="flex items-start space-x-2">
                  <Checkbox
                    id={`menu-${item.id}`}
                    onCheckedChange={(checked) => handleCheckboxChange("menu_ids", item.id, checked as boolean)}
                    className="border-batik-brown/50 data-[state=checked]:bg-batik-brown data-[state=checked]:border-batik-brown"
                  />
                  <Label htmlFor={`menu-${item.id}`} className="text-sm font-normal cursor-pointer">
                    {item.nama}
                    <span className="block text-xs text-batik-brown/70">Rp {item.harga?.toLocaleString()}</span>
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium text-batik-brown mb-3">Kebutuhan Tambahan</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[150px] overflow-y-auto p-2 border border-batik-brown/20 rounded-md bg-white">
              {kebutuhanTambahan.map((item) => (
                <div key={item.id} className="flex items-start space-x-2">
                  <Checkbox
                    id={`kebutuhan-${item.id}`}
                    onCheckedChange={(checked) =>
                      handleCheckboxChange("kebutuhan_tambahan_ids", item.id, checked as boolean)
                    }
                    className="border-batik-brown/50 data-[state=checked]:bg-batik-brown data-[state=checked]:border-batik-brown"
                  />
                  <Label htmlFor={`kebutuhan-${item.id}`} className="text-sm font-normal cursor-pointer">
                    {item.nama}
                    {item.biaya > 0 && (
                      <span className="block text-xs text-batik-brown/70">Rp {item.biaya?.toLocaleString()}</span>
                    )}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium text-batik-brown mb-3">Fasilitas Tambahan</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[150px] overflow-y-auto p-2 border border-batik-brown/20 rounded-md bg-white">
              {fasilitasTambahan.map((item) => (
                <div key={item.id} className="flex items-start space-x-2">
                  <Checkbox
                    id={`fasilitas-${item.id}`}
                    onCheckedChange={(checked) =>
                      handleCheckboxChange("fasilitas_tambahan_ids", item.id, checked as boolean)
                    }
                    className="border-batik-brown/50 data-[state=checked]:bg-batik-brown data-[state=checked]:border-batik-brown"
                  />
                  <Label htmlFor={`fasilitas-${item.id}`} className="text-sm font-normal cursor-pointer">
                    {item.nama}
                    {item.biaya > 0 && (
                      <span className="block text-xs text-batik-brown/70">Rp {item.biaya?.toLocaleString()}</span>
                    )}
                  </Label>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-4 pt-4 border-t border-batik-brown/20">
        <Button
          type="button"
          variant="outline"
          onClick={() => router.back()}
          className="border-batik-brown text-batik-brown hover:bg-batik-brown/10"
        >
          Batal
        </Button>
        <Button type="submit" disabled={isLoading} className="bg-batik-brown hover:bg-batik-darkGreen text-batik-cream">
          {isLoading ? "Menyimpan..." : "Simpan Reservasi"}
        </Button>
      </div>
    </form>
  )
}

