import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, ChevronLeft } from "lucide-react"
import Link from "next/link"
import { getMenuItemsByCategory, getFasilitasTambahan } from "@/lib/supabase"
import { FormReservasiDetail } from "./form-reservasi-detail"

export default async function TambahReservasiPage() {
  // Ambil data menu berdasarkan kategori
  const makanan = await getMenuItemsByCategory("makanan")
  const minuman = await getMenuItemsByCategory("minuman")
  const fasilitasTambahan = await getFasilitasTambahan()

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-8 bg-batik-cream/30">
        <div className="container">
          <div className="flex items-center mb-8">
            <Link href="/reservasi" className="text-batik-brown hover:text-batik-deepRed mr-4">
              <ChevronLeft className="h-5 w-5" />
            </Link>
            <h1 className="text-3xl font-bold text-batik-brown font-javanese">Tambah Reservasi</h1>
          </div>

          <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-batik-brown flex items-center gap-2">
                <Calendar className="h-5 w-5 text-batik-gold" />
                Form Reservasi Baru
              </CardTitle>
              <CardDescription>Isi data reservasi dengan lengkap</CardDescription>
            </CardHeader>
            <CardContent>
              <FormReservasiDetail makanan={makanan} minuman={minuman} fasilitasTambahan={fasilitasTambahan} />
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  )
}

