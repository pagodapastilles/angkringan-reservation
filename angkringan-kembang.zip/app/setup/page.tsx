"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Database, CheckCircle2, AlertCircle, ArrowRight } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { toast } from "@/hooks/use-toast"
import Link from "next/link"

export default function SetupPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [setupComplete, setSetupComplete] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSetup = async () => {
    setIsLoading(true)
    setError(null)

    try {
      // Test connection
      const { error: connectionError } = await supabase.from("kategori_menu").select("count")

      if (connectionError) {
        // If table doesn't exist, create all tables
        const setupSQL = `
          -- SQL setup script here (copy from setup.sql)
        `

        // Execute setup SQL
        const { error: setupError } = await supabase.rpc("exec_sql", { sql: setupSQL })

        if (setupError) {
          throw setupError
        }

        toast({
          title: "Setup berhasil",
          description: "Database telah berhasil diinisialisasi",
        })

        setSetupComplete(true)
      } else {
        // Tables already exist
        toast({
          title: "Database sudah ada",
          description: "Tabel-tabel yang diperlukan sudah tersedia",
        })

        setSetupComplete(true)
      }
    } catch (error: any) {
      console.error("Setup error:", error)
      setError(error.message)
      toast({
        title: "Setup gagal",
        description: "Terjadi kesalahan saat melakukan setup database",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-8 bg-batik-cream/30">
        <div className="container max-w-2xl">
          <Card className="border-batik-brown/30 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-batik-brown flex items-center gap-2">
                <Database className="h-5 w-5" />
                Setup Database
              </CardTitle>
              <CardDescription>Inisialisasi database untuk sistem manajemen reservasi</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {setupComplete ? (
                <Alert className="border-green-200 bg-green-50">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <AlertTitle className="text-green-800">Setup Selesai</AlertTitle>
                  <AlertDescription className="text-green-700">
                    <p className="mb-2">Database telah berhasil diinisialisasi.</p>
                    <Link href="/dashboard">
                      <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white">
                        Ke Dashboard <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="space-y-4">
                  <p className="text-sm text-batik-brown/70">
                    Klik tombol di bawah untuk membuat tabel-tabel yang diperlukan di database Supabase Anda. Pastikan
                    Anda telah mengatur environment variables NEXT_PUBLIC_SUPABASE_URL dan NEXT_PUBLIC_SUPABASE_ANON_KEY
                    dengan benar.
                  </p>

                  <Button
                    onClick={handleSetup}
                    disabled={isLoading}
                    className="w-full bg-batik-brown hover:bg-batik-darkGreen text-batik-cream"
                  >
                    {isLoading ? (
                      <>
                        <span className="mr-2">Memproses...</span>
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                      </>
                    ) : (
                      "Mulai Setup"
                    )}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  )
}

