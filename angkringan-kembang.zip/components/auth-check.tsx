"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { getAuthenticatedAdmin, isSessionExpired, logoutAdmin } from "@/lib/auth"

export function AuthCheck({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const pathname = usePathname()
  const [isChecking, setIsChecking] = useState(true)

  useEffect(() => {
    // Skip auth check for login page
    if (pathname === "/login") {
      setIsChecking(false)
      return
    }

    // Check if user is authenticated
    const admin = getAuthenticatedAdmin()

    if (!admin) {
      // If not authenticated, redirect to login
      router.push("/login")
      return
    }

    // Check if session is expired
    if (isSessionExpired()) {
      // If session expired, logout and redirect to login
      logoutAdmin()
      router.push("/login")
      return
    }

    // If authenticated and session not expired, show content
    setIsChecking(false)
  }, [pathname, router])

  if (isChecking && pathname !== "/login") {
    // Show loading state during auth check
    return (
      <div className="min-h-screen flex items-center justify-center bg-batik-cream/30">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-batik-gold border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-batik-brown">Memuat...</p>
        </div>
      </div>
    )
  }

  return <>{children}</>
}

