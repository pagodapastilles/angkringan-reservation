import { Leaf, Mail, Phone, MapPin } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t bg-batik-darkGreen text-batik-cream">
      <div className="container py-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
            <Leaf className="h-5 w-5 text-batik-gold" />
            <span className="font-bold font-javanese">Angkringan Kembang</span>
          </div>
          <div className="flex flex-col md:flex-row gap-4 md:gap-8 items-center text-sm">
            <div className="flex items-center gap-1">
              <MapPin className="h-4 w-4 text-batik-gold" />
              <span>Jl. Kembang Indah No. 123, Yogyakarta</span>
            </div>
            <div className="flex items-center gap-1">
              <Phone className="h-4 w-4 text-batik-gold" />
              <span>(0274) 123456</span>
            </div>
            <div className="flex items-center gap-1">
              <Mail className="h-4 w-4 text-batik-gold" />
              <span>info@angkringankembang.com</span>
            </div>
          </div>
        </div>
        <div className="mt-4 pt-4 border-t border-batik-cream/20 text-center text-xs text-batik-cream/70">
          &copy; {new Date().getFullYear()} Angkringan Kembang. All rights reserved.
        </div>
      </div>
    </footer>
  )
}

