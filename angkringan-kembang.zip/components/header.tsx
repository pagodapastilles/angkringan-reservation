"use client"

import Link from "next/link"
import { Leaf, Menu, Calendar, Home, ChefHat, Settings, LogOut, User } from "lucide-react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { ModeToggle } from "./mode-toggle"
import { useEffect, useState } from "react"
import { getAuthenticatedAdmin, logoutAdmin } from "@/lib/auth"
import { toast } from "@/hooks/use-toast"

export function Header() {
  const router = useRouter()
  const [admin, setAdmin] = useState<any>(null)

  useEffect(() => {
    // Get authenticated admin on client side
    const adminData = getAuthenticatedAdmin()
    setAdmin(adminData)
  }, [])

  const handleLogout = () => {
    logoutAdmin()
    toast({
      title: "Logout berhasil",
      description: "Anda telah keluar dari sistem",
    })
    router.push("/login")
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-batik-brown text-batik-cream shadow-md">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <Leaf className="h-6 w-6 text-batik-gold" />
            <span className="font-bold text-xl font-javanese">Angkringan Kembang</span>
          </Link>
        </div>
        <nav className="hidden md:flex items-center gap-6">
          <Link
            href="/dashboard"
            className="text-sm font-medium hover:text-batik-gold transition-colors flex items-center gap-1"
          >
            <Home className="h-4 w-4" />
            <span>Dashboard</span>
          </Link>
          <Link
            href="/reservasi"
            className="text-sm font-medium hover:text-batik-gold transition-colors flex items-center gap-1"
          >
            <Calendar className="h-4 w-4" />
            <span>Reservasi</span>
          </Link>
          <Link
            href="/dapur"
            className="text-sm font-medium hover:text-batik-gold transition-colors flex items-center gap-1"
          >
            <ChefHat className="h-4 w-4" />
            <span>Kebutuhan Dapur</span>
          </Link>
          <Link
            href="/pengaturan"
            className="text-sm font-medium hover:text-batik-gold transition-colors flex items-center gap-1"
          >
            <Settings className="h-4 w-4" />
            <span>Pengaturan</span>
          </Link>
        </nav>
        <div className="flex items-center gap-2">
          {admin && (
            <div className="hidden md:flex items-center mr-2 text-sm">
              <User className="h-4 w-4 mr-1 text-batik-gold" />
              <span>{admin.nama}</span>
            </div>
          )}
          <ModeToggle />
          <Button variant="ghost" size="icon" className="text-batik-cream hover:text-batik-gold" onClick={handleLogout}>
            <LogOut className="h-5 w-5" />
            <span className="sr-only">Logout</span>
          </Button>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden text-batik-cream hover:text-batik-gold">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-batik-cream border-batik-brown">
              <div className="flex items-center gap-2 mb-8 mt-4">
                <Leaf className="h-6 w-6 text-batik-brown" />
                <span className="font-bold text-xl text-batik-brown font-javanese">Angkringan Kembang</span>
              </div>
              {admin && (
                <div className="mb-4 pb-4 border-b border-batik-brown/20">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-batik-brown/20 flex items-center justify-center mr-2">
                      <User className="h-4 w-4 text-batik-brown" />
                    </div>
                    <div>
                      <p className="font-medium text-batik-brown">{admin.nama}</p>
                      <p className="text-xs text-batik-brown/70">
                        {admin.role === "super_admin" ? "Super Admin" : "Admin"}
                      </p>
                    </div>
                  </div>
                </div>
              )}
              <nav className="flex flex-col gap-4">
                <Link
                  href="/dashboard"
                  className="text-batik-brown hover:text-batik-deepRed transition-colors flex items-center gap-2"
                >
                  <Home className="h-5 w-5" />
                  <span>Dashboard</span>
                </Link>
                <Link
                  href="/reservasi"
                  className="text-batik-brown hover:text-batik-deepRed transition-colors flex items-center gap-2"
                >
                  <Calendar className="h-5 w-5" />
                  <span>Reservasi</span>
                </Link>
                <Link
                  href="/dapur"
                  className="text-batik-brown hover:text-batik-deepRed transition-colors flex items-center gap-2"
                >
                  <ChefHat className="h-5 w-5" />
                  <span>Kebutuhan Dapur</span>
                </Link>
                <Link
                  href="/pengaturan"
                  className="text-batik-brown hover:text-batik-deepRed transition-colors flex items-center gap-2"
                >
                  <Settings className="h-5 w-5" />
                  <span>Pengaturan</span>
                </Link>
                <hr className="border-batik-brown/30 my-2" />
                <Button
                  variant="ghost"
                  className="justify-start p-0 text-batik-brown hover:text-batik-deepRed"
                  onClick={handleLogout}
                >
                  <LogOut className="h-5 w-5 mr-2" />
                  <span>Logout</span>
                </Button>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}

