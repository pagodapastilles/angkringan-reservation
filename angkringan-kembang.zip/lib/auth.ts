import { supabase } from "./supabase"

// Fallback admin credentials when the database table doesn't exist yet
const FALLBACK_ADMIN = {
  id: 1,
  username: "admin",
  password: "admin123", // In a real app, passwords should be hashed
  nama: "Admin Utama",
  role: "admin",
  aktif: true,
}

export async function loginAdmin(username: string, password: string) {
  try {
    // First, check if the admin table exists
    const { error: tableCheckError } = await supabase.from("admin").select("count").limit(1)

    // If the table doesn't exist, use fallback admin
    if (
      tableCheckError &&
      tableCheckError.message.includes("relation") &&
      tableCheckError.message.includes("does not exist")
    ) {
      console.log("Admin table doesn't exist yet, using fallback admin")

      // Check if credentials match the fallback admin
      if (username === FALLBACK_ADMIN.username && password === FALLBACK_ADMIN.password) {
        const { password: _, ...adminData } = FALLBACK_ADMIN
        return adminData
      }
      return null
    }

    // If the table exists, try to authenticate normally
    const { data, error } = await supabase
      .from("admin")
      .select("*")
      .eq("username", username)
      .eq("password", password) // In a real app, use secure authentication
      .eq("aktif", true)
      .single()

    if (error && !error.message.includes("does not exist")) {
      console.error("Login error:", error)
      return null
    }

    // Return admin data without the password
    if (data) {
      const { password: _, ...adminData } = data
      return adminData
    }

    // If we get here, check if credentials match the fallback admin
    if (username === FALLBACK_ADMIN.username && password === FALLBACK_ADMIN.password) {
      const { password: _, ...adminData } = FALLBACK_ADMIN
      return adminData
    }

    return null
  } catch (error) {
    console.error("Error during login:", error)

    // As a last resort, check if credentials match the fallback admin
    if (username === FALLBACK_ADMIN.username && password === FALLBACK_ADMIN.password) {
      const { password: _, ...adminData } = FALLBACK_ADMIN
      return adminData
    }

    return null
  }
}

// Dapatkan admin yang sudah terotentikasi
export function getAuthenticatedAdmin() {
  if (typeof window === "undefined") {
    return null
  }

  const adminData = localStorage.getItem("admin")
  if (!adminData) {
    return null
  }

  try {
    return JSON.parse(adminData)
  } catch (error) {
    console.error("Error parsing admin data:", error)
    return null
  }
}

// Periksa apakah sesi sudah berakhir (4 jam)
export function isSessionExpired() {
  if (typeof window === "undefined") {
    return true
  }

  const loginTime = localStorage.getItem("loginTime")
  if (!loginTime) {
    return true
  }

  const loginDate = new Date(loginTime)
  const now = new Date()
  const fourHoursInMs = 4 * 60 * 60 * 1000

  return now.getTime() - loginDate.getTime() > fourHoursInMs
}

// Fungsi logout
export function logoutAdmin() {
  if (typeof window === "undefined") {
    return
  }

  localStorage.removeItem("admin")
  localStorage.removeItem("loginTime")
}

