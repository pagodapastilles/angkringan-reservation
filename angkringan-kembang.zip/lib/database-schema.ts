import { supabase } from "./supabase"

export async function setupDatabase() {
  try {
    // Create admin table
    const { error: adminError } = await supabase.query(`
      CREATE TABLE IF NOT EXISTS admin (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        nama TEXT NOT NULL,
        role TEXT NOT NULL CHECK (role IN ('admin', 'super_admin')),
        aktif BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    if (adminError) {
      console.error("Error creating admin table:", adminError)
      return { success: false, error: adminError }
    }

    // Create kategori_menu table
    const { error: kategoriMenuError } = await supabase.query(`
      CREATE TABLE IF NOT EXISTS kategori_menu (
        id SERIAL PRIMARY KEY,
        nama TEXT NOT NULL,
        deskripsi TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    if (kategoriMenuError) {
      console.error("Error creating kategori_menu table:", kategoriMenuError)
      return { success: false, error: kategoriMenuError }
    }

    // Create menu table
    const { error: menuError } = await supabase.query(`
      CREATE TABLE IF NOT EXISTS menu (
        id SERIAL PRIMARY KEY,
        nama TEXT NOT NULL,
        kategori_id INTEGER REFERENCES kategori_menu(id),
        harga INTEGER NOT NULL,
        deskripsi TEXT,
        gambar_url TEXT,
        tersedia BOOLEAN DEFAULT TRUE,
        is_paket BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    if (menuError) {
      console.error("Error creating menu table:", menuError)
      return { success: false, error: menuError }
    }

    // Create menu_paket_item table
    const { error: menuPaketError } = await supabase.query(`
      CREATE TABLE IF NOT EXISTS menu_paket_item (
        id SERIAL PRIMARY KEY,
        paket_id INTEGER REFERENCES menu(id),
        menu_id INTEGER REFERENCES menu(id),
        jumlah INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    if (menuPaketError) {
      console.error("Error creating menu_paket_item table:", menuPaketError)
      return { success: false, error: menuPaketError }
    }

    // Create kategori_bahan table
    const { error: kategoriBahanError } = await supabase.query(`
      CREATE TABLE IF NOT EXISTS kategori_bahan (
        id SERIAL PRIMARY KEY,
        nama TEXT NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    if (kategoriBahanError) {
      console.error("Error creating kategori_bahan table:", kategoriBahanError)
      return { success: false, error: kategoriBahanError }
    }

    // Create bahan table
    const { error: bahanError } = await supabase.query(`
      CREATE TABLE IF NOT EXISTS bahan (
        id SERIAL PRIMARY KEY,
        nama TEXT NOT NULL,
        kategori_id INTEGER REFERENCES kategori_bahan(id),
        satuan TEXT NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    if (bahanError) {
      console.error("Error creating bahan table:", bahanError)
      return { success: false, error: bahanError }
    }

    // Create resep table
    const { error: resepError } = await supabase.query(`
      CREATE TABLE IF NOT EXISTS resep (
        id SERIAL PRIMARY KEY,
        menu_id INTEGER REFERENCES menu(id),
        bahan_id INTEGER REFERENCES bahan(id),
        jumlah DECIMAL(10, 2) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(menu_id, bahan_id)
      )
    `)

    if (resepError) {
      console.error("Error creating resep table:", resepError)
      return { success: false, error: resepError }
    }

    // Create fasilitas_tambahan table
    const { error: fasilitasError } = await supabase.query(`
      CREATE TABLE IF NOT EXISTS fasilitas_tambahan (
        id SERIAL PRIMARY KEY,
        nama TEXT NOT NULL,
        biaya INTEGER NOT NULL DEFAULT 0,
        deskripsi TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    if (fasilitasError) {
      console.error("Error creating fasilitas_tambahan table:", fasilitasError)
      return { success: false, error: fasilitasError }
    }

    // Create meja table
    const { error: mejaError } = await supabase.query(`
      CREATE TABLE IF NOT EXISTS meja (
        id SERIAL PRIMARY KEY,
        nomor TEXT NOT NULL UNIQUE,
        kapasitas INTEGER NOT NULL DEFAULT 4,
        lokasi TEXT,
        status TEXT DEFAULT 'tersedia' CHECK (status IN ('tersedia', 'terpesan', 'maintenance')),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    if (mejaError) {
      console.error("Error creating meja table:", mejaError)
      return { success: false, error: mejaError }
    }

    // Create reservasi table
    const { error: reservasiError } = await supabase.query(`
      CREATE TABLE IF NOT EXISTS reservasi (
        id SERIAL PRIMARY KEY,
        nama_pemesan TEXT NOT NULL,
        telepon TEXT NOT NULL,
        email TEXT,
        jumlah_tamu INTEGER NOT NULL,
        tanggal_reservasi DATE NOT NULL,
        jam_reservasi TIME NOT NULL,
        meja_id INTEGER REFERENCES meja(id),
        status_pembayaran TEXT NOT NULL DEFAULT 'belum_bayar' CHECK (status_pembayaran IN ('belum_bayar', 'dp', 'lunas')),
        metode_pembayaran TEXT CHECK (metode_pembayaran IN ('tunai', 'transfer', 'debit', 'qris')),
        jumlah_dp INTEGER,
        total_biaya INTEGER NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'terkonfirmasi' CHECK (status IN ('terkonfirmasi', 'selesai', 'dibatalkan')),
        catatan TEXT,
        admin_id INTEGER REFERENCES admin(id),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    if (reservasiError) {
      console.error("Error creating reservasi table:", reservasiError)
      return { success: false, error: reservasiError }
    }

    // Create item_pesanan table
    const { error: itemPesananError } = await supabase.query(`
      CREATE TABLE IF NOT EXISTS item_pesanan (
        id SERIAL PRIMARY KEY,
        reservasi_id INTEGER REFERENCES reservasi(id) ON DELETE CASCADE,
        menu_id INTEGER REFERENCES menu(id),
        jumlah INTEGER NOT NULL DEFAULT 1,
        catatan TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    if (itemPesananError) {
      console.error("Error creating item_pesanan table:", itemPesananError)
      return { success: false, error: itemPesananError }
    }

    // Create fasilitas_reservasi table
    const { error: fasilitasReservasiError } = await supabase.query(`
      CREATE TABLE IF NOT EXISTS fasilitas_reservasi (
        id SERIAL PRIMARY KEY,
        reservasi_id INTEGER REFERENCES reservasi(id) ON DELETE CASCADE,
        fasilitas_id INTEGER REFERENCES fasilitas_tambahan(id),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    if (fasilitasReservasiError) {
      console.error("Error creating fasilitas_reservasi table:", fasilitasReservasiError)
      return { success: false, error: fasilitasReservasiError }
    }

    console.log("Database setup completed successfully")
    return { success: true }
  } catch (error) {
    console.error("Error setting up database:", error)
    return { success: false, error }
  }
}

