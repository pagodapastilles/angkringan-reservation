import { supabase } from "./supabase"

export async function setupDatabase() {
  // Create menu_categories table
  const { error: categoriesError } = await supabase.rpc("create_table_if_not_exists", {
    table_name: "menu_categories",
    table_definition: `
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      description TEXT,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    `,
  })

  if (categoriesError) {
    console.error("Error creating menu_categories table:", categoriesError)
    return
  }

  // Create menu_items table
  const { error: itemsError } = await supabase.rpc("create_table_if_not_exists", {
    table_name: "menu_items",
    table_definition: `
      id SERIAL PRIMARY KEY,
      category_id INTEGER REFERENCES menu_categories(id),
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      description TEXT,
      price INTEGER NOT NULL,
      image_url TEXT,
      is_available BOOLEAN DEFAULT TRUE,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    `,
  })

  if (itemsError) {
    console.error("Error creating menu_items table:", itemsError)
    return
  }

  // Create orders table
  const { error: ordersError } = await supabase.rpc("create_table_if_not_exists", {
    table_name: "orders",
    table_definition: `
      id SERIAL PRIMARY KEY,
      customer_name TEXT NOT NULL,
      customer_email TEXT,
      customer_phone TEXT,
      total_amount INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    `,
  })

  if (ordersError) {
    console.error("Error creating orders table:", ordersError)
    return
  }

  // Create order_items table
  const { error: orderItemsError } = await supabase.rpc("create_table_if_not_exists", {
    table_name: "order_items",
    table_definition: `
      id SERIAL PRIMARY KEY,
      order_id INTEGER REFERENCES orders(id),
      menu_item_id INTEGER REFERENCES menu_items(id),
      quantity INTEGER NOT NULL,
      price INTEGER NOT NULL,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    `,
  })

  if (orderItemsError) {
    console.error("Error creating order_items table:", orderItemsError)
    return
  }

  console.log("Database schema setup completed successfully")
}

