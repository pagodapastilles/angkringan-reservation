import { supabase } from "./supabase"

export async function seedInitialData() {
  try {
    // Seed admin user
    const { error: adminError } = await supabase
      .from("admin")
      .upsert([
        {
          username: "admin",
          password: "admin123", // In a real app, use hashed passwords
          nama: "Admin Utama",
          role: "admin",
          aktif: true,
        },
        {
          username: "manager",
          password: "manager123",
          nama: "Manager Restoran",
          role: "super_admin",
          aktif: true,
        },
      ])
      .select()

    if (adminError) {
      console.error("Error seeding admin data:", adminError)
      return { success: false, error: adminError }
    }

    // Seed kategori menu
    const { error: kategoriMenuError } = await supabase
      .from("kategori_menu")
      .upsert([
        { nama: "Makanan Utama", deskripsi: "Menu makanan utama" },
        { nama: "Minuman", deskripsi: "Menu minuman" },
        { nama: "Camilan", deskripsi: "Menu camilan" },
        { nama: "Paket", deskripsi: "Menu paket" },
      ])
      .select()

    if (kategoriMenuError) {
      console.error("Error seeding kategori menu data:", kategoriMenuError)
      return { success: false, error: kategoriMenuError }
    }

    // Get kategori IDs
    const { data: kategoriData, error: getKategoriError } = await supabase.from("kategori_menu").select("id, nama")

    if (getKategoriError || !kategoriData) {
      console.error("Error getting kategori data:", getKategoriError)
      return { success: false, error: getKategoriError }
    }

    const kategoriMap = kategoriData.reduce(
      (acc, curr) => {
        acc[curr.nama] = curr.id
        return acc
      },
      {} as Record<string, number>,
    )

    // Seed menu
    const { error: menuError } = await supabase
      .from("menu")
      .upsert([
        {
          nama: "Nasi Gudeg",
          kategori_id: kategoriMap["Makanan Utama"],
          harga: 25000,
          deskripsi: "Nasi dengan gudeg khas Jogja",
          tersedia: true,
        },
        {
          nama: "Nasi Pecel",
          kategori_id: kategoriMap["Makanan Utama"],
          harga: 20000,
          deskripsi: "Nasi dengan sayuran dan bumbu pecel",
          tersedia: true,
        },
        {
          nama: "Es Teh",
          kategori_id: kategoriMap["Minuman"],
          harga: 5000,
          deskripsi: "Teh manis dingin",
          tersedia: true,
        },
        {
          nama: "Wedang Jahe",
          kategori_id: kategoriMap["Minuman"],
          harga: 8000,
          deskripsi: "Minuman jahe hangat",
          tersedia: true,
        },
        {
          nama: "Tempe Mendoan",
          kategori_id: kategoriMap["Camilan"],
          harga: 12000,
          deskripsi: "Tempe goreng tepung",
          tersedia: true,
        },
        {
          nama: "Paket Keluarga",
          kategori_id: kategoriMap["Paket"],
          harga: 100000,
          deskripsi: "Paket makanan untuk 4 orang",
          tersedia: true,
          is_paket: true,
        },
      ])
      .select()

    if (menuError) {
      console.error("Error seeding menu data:", menuError)
      return { success: false, error: menuError }
    }

    // Seed kategori bahan
    const { error: kategoriBahanError } = await supabase
      .from("kategori_bahan")
      .upsert([
        { nama: "Bahan Pokok" },
        { nama: "Sayuran" },
        { nama: "Bumbu" },
        { nama: "Protein" },
        { nama: "Minuman" },
      ])
      .select()

    if (kategoriBahanError) {
      console.error("Error seeding kategori bahan data:", kategoriBahanError)
      return { success: false, error: kategoriBahanError }
    }

    // Get kategori bahan IDs
    const { data: kategoriBahanData, error: getKategoriBahanError } = await supabase
      .from("kategori_bahan")
      .select("id, nama")

    if (getKategoriBahanError || !kategoriBahanData) {
      console.error("Error getting kategori bahan data:", getKategoriBahanError)
      return { success: false, error: getKategoriBahanError }
    }

    const kategoriBahanMap = kategoriBahanData.reduce(
      (acc, curr) => {
        acc[curr.nama] = curr.id
        return acc
      },
      {} as Record<string, number>,
    )

    // Seed bahan
    const { error: bahanError } = await supabase
      .from("bahan")
      .upsert([
        { nama: "Beras", kategori_id: kategoriBahanMap["Bahan Pokok"], satuan: "kg" },
        { nama: "Gula", kategori_id: kategoriBahanMap["Bahan Pokok"], satuan: "kg" },
        { nama: "Nangka Muda", kategori_id: kategoriBahanMap["Sayuran"], satuan: "kg" },
        { nama: "Kacang Panjang", kategori_id: kategoriBahanMap["Sayuran"], satuan: "ikat" },
        { nama: "Cabai", kategori_id: kategoriBahanMap["Bumbu"], satuan: "kg" },
        { nama: "Bawang Merah", kategori_id: kategoriBahanMap["Bumbu"], satuan: "kg" },
        { nama: "Bawang Putih", kategori_id: kategoriBahanMap["Bumbu"], satuan: "kg" },
        { nama: "Ayam", kategori_id: kategoriBahanMap["Protein"], satuan: "ekor" },
        { nama: "Tempe", kategori_id: kategoriBahanMap["Protein"], satuan: "papan" },
        { nama: "Teh", kategori_id: kategoriBahanMap["Minuman"], satuan: "box" },
        { nama: "Jahe", kategori_id: kategoriBahanMap["Bumbu"], satuan: "kg" },
      ])
      .select()

    if (bahanError) {
      console.error("Error seeding bahan data:", bahanError)
      return { success: false, error: bahanError }
    }

    // Seed fasilitas tambahan
    const { error: fasilitasError } = await supabase
      .from("fasilitas_tambahan")
      .upsert([
        { nama: "Ruang VIP", biaya: 100000, deskripsi: "Ruangan privat untuk acara khusus" },
        { nama: "Dekorasi", biaya: 50000, deskripsi: "Dekorasi meja dan ruangan" },
        { nama: "Live Music", biaya: 200000, deskripsi: "Pertunjukan musik live" },
        { nama: "Proyektor", biaya: 75000, deskripsi: "Proyektor dan layar" },
      ])
      .select()

    if (fasilitasError) {
      console.error("Error seeding fasilitas data:", fasilitasError)
      return { success: false, error: fasilitasError }
    }

    // Seed meja
    const { error: mejaError } = await supabase
      .from("meja")
      .upsert([
        { nomor: "A1", kapasitas: 2, lokasi: "Indoor", status: "tersedia" },
        { nomor: "A2", kapasitas: 2, lokasi: "Indoor", status: "tersedia" },
        { nomor: "B1", kapasitas: 4, lokasi: "Indoor", status: "tersedia" },
        { nomor: "B2", kapasitas: 4, lokasi: "Indoor", status: "tersedia" },
        { nomor: "C1", kapasitas: 6, lokasi: "Outdoor", status: "tersedia" },
        { nomor: "C2", kapasitas: 6, lokasi: "Outdoor", status: "tersedia" },
        { nomor: "D1", kapasitas: 8, lokasi: "VIP", status: "tersedia" },
      ])
      .select()

    if (mejaError) {
      console.error("Error seeding meja data:", mejaError)
      return { success: false, error: mejaError }
    }

    // Get menu IDs for resep
    const { data: menuData, error: getMenuError } = await supabase.from("menu").select("id, nama")

    if (getMenuError || !menuData) {
      console.error("Error getting menu data:", getMenuError)
      return { success: false, error: getMenuError }
    }

    const menuMap = menuData.reduce(
      (acc, curr) => {
        acc[curr.nama] = curr.id
        return acc
      },
      {} as Record<string, number>,
    )

    // Get bahan IDs for resep
    const { data: bahanData, error: getBahanError } = await supabase.from("bahan").select("id, nama")

    if (getBahanError || !bahanData) {
      console.error("Error getting bahan data:", getBahanError)
      return { success: false, error: getBahanError }
    }

    const bahanMap = bahanData.reduce(
      (acc, curr) => {
        acc[curr.nama] = curr.id
        return acc
      },
      {} as Record<string, number>,
    )

    // Seed resep
    const { error: resepError } = await supabase
      .from("resep")
      .upsert([
        { menu_id: menuMap["Nasi Gudeg"], bahan_id: bahanMap["Beras"], jumlah: 0.1 },
        { menu_id: menuMap["Nasi Gudeg"], bahan_id: bahanMap["Nangka Muda"], jumlah: 0.2 },
        { menu_id: menuMap["Nasi Gudeg"], bahan_id: bahanMap["Ayam"], jumlah: 0.25 },
        { menu_id: menuMap["Nasi Pecel"], bahan_id: bahanMap["Beras"], jumlah: 0.1 },
        { menu_id: menuMap["Nasi Pecel"], bahan_id: bahanMap["Kacang Panjang"], jumlah: 0.1 },
        { menu_id: menuMap["Nasi Pecel"], bahan_id: bahanMap["Cabai"], jumlah: 0.05 },
        { menu_id: menuMap["Es Teh"], bahan_id: bahanMap["Teh"], jumlah: 0.01 },
        { menu_id: menuMap["Es Teh"], bahan_id: bahanMap["Gula"], jumlah: 0.02 },
        { menu_id: menuMap["Wedang Jahe"], bahan_id: bahanMap["Jahe"], jumlah: 0.05 },
        { menu_id: menuMap["Wedang Jahe"], bahan_id: bahanMap["Gula"], jumlah: 0.02 },
        { menu_id: menuMap["Tempe Mendoan"], bahan_id: bahanMap["Tempe"], jumlah: 0.5 },
      ])
      .select()

    if (resepError) {
      console.error("Error seeding resep data:", resepError)
      return { success: false, error: resepError }
    }

    console.log("Data seeding completed successfully")
    return { success: true }
  } catch (error) {
    console.error("Error seeding data:", error)
    return { success: false, error }
  }
}

