import { createClient } from "@supabase/supabase-js"
import type { Database } from "./database.types"
import type { MenuItem, FasilitasTambahan, Reservasi, BahanResep } from "./types"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error("Missing Supabase environment variables")
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey)

// Fungsi untuk login admin
export async function loginAdmin(username: string, password: string) {
  const { data, error } = await supabase
    .from("admin")
    .select("*")
    .eq("username", username)
    .eq("password", password) // Dalam aplikasi nyata, gunakan autentikasi yang lebih aman
    .eq("aktif", true)
    .single()

  if (error) {
    throw error
  }

  return data
}

// Fungsi untuk mengambil data menu
export async function getMenuItems(): Promise<MenuItem[]> {
  const { data, error } = await supabase.from("menu_items").select("*").order("name")

  if (error) {
    console.error("Error fetching menu items:", error)
    return []
  }

  return data || []
}

// Fungsi untuk mengambil data menu berdasarkan kategori
export async function getMenuItemsByCategory(kategori: "makanan" | "minuman"): Promise<MenuItem[]> {
  const { data, error } = await supabase
    .from("menu_items")
    .select("*")
    .eq("category_id", kategori === "makanan" ? 1 : 2)
    .order("name")

  if (error) {
    console.error(`Error fetching ${kategori}:`, error)
    return []
  }

  return data || []
}

// Fungsi untuk mengambil data fasilitas tambahan
export async function getFasilitasTambahan(): Promise<FasilitasTambahan[]> {
  const { data, error } = await supabase.from("fasilitas_tambahan").select("*").order("nama")

  if (error) {
    console.error("Error fetching fasilitas tambahan:", error)
    return []
  }

  return data || []
}

// Fungsi untuk mengambil data kebutuhan tambahan
export async function getKebutuhanTambahan(): Promise<any[]> {
  const { data, error } = await supabase.from("kebutuhan_tambahan").select("*").order("nama")

  if (error) {
    console.error("Error fetching kebutuhan tambahan:", error)
    return []
  }

  return data || []
}

// Fungsi untuk mengambil data reservasi
export async function getReservations(): Promise<Reservasi[]> {
  const { data, error } = await supabase
    .from("reservasi")
    .select(`
      *,
      admin:admin_id(nama)
    `)
    .order("tanggal_reservasi", { ascending: true })

  if (error) {
    console.error("Error fetching reservations:", error)
    return []
  }

  return data || []
}

// Fungsi untuk menambahkan reservasi baru
export async function addReservation(reservationData: any, itemPesanan: any[]) {
  // Tambahkan reservasi
  const { data: reservasi, error: reservasiError } = await supabase
    .from("reservasi")
    .insert(reservationData)
    .select()
    .single()

  if (reservasiError) {
    console.error("Error adding reservation:", reservasiError)
    throw reservasiError
  }

  // Tambahkan item pesanan
  const pesananWithReservasiId = itemPesanan.map((item) => ({
    ...item,
    reservasi_id: reservasi.id,
  }))

  const { error: pesananError } = await supabase.from("item_pesanan").insert(pesananWithReservasiId)

  if (pesananError) {
    console.error("Error adding order items:", pesananError)
    throw pesananError
  }

  return reservasi
}

// Fungsi untuk menghapus reservasi
export async function deleteReservation(id: number) {
  const { error } = await supabase.from("reservasi").delete().eq("id", id)

  if (error) {
    console.error("Error deleting reservation:", error)
    throw error
  }
}

// Fungsi untuk mengambil data reservasi berdasarkan tanggal
export async function getReservationsByDate(date: string): Promise<Reservasi[]> {
  const { data, error } = await supabase
    .from("reservasi")
    .select(`
      *,
      admin:admin_id(nama)
    `)
    .eq("tanggal_reservasi", date)
    .order("waktu_reservasi")

  if (error) {
    console.error("Error fetching reservations by date:", error)
    return []
  }

  return data || []
}

// Fungsi untuk mengambil item pesanan berdasarkan reservasi ID
export async function getOrderItemsByReservationId(reservasiId: number): Promise<any[]> {
  const { data, error } = await supabase
    .from("item_pesanan")
    .select(`
      *,
      menu:menu_id(*)
    `)
    .eq("reservasi_id", reservasiId)

  if (error) {
    console.error("Error fetching order items:", error)
    return []
  }

  return data || []
}

// Fungsi untuk mengambil data bahan resep
export async function getBahanResep(): Promise<BahanResep[]> {
  const { data, error } = await supabase.from("bahan_resep").select("*").order("kategori").order("nama")

  if (error) {
    console.error("Error fetching bahan resep:", error)
    return []
  }

  return data || []
}

// Fungsi untuk mengambil data resep berdasarkan menu ID
export async function getResepByMenuId(menuId: number): Promise<any[]> {
  const { data, error } = await supabase
    .from("resep")
    .select(`
      *,
      bahan:bahan_id(*)
    `)
    .eq("menu_id", menuId)

  if (error) {
    console.error("Error fetching resep:", error)
    return []
  }

  return data || []
}

// Fungsi untuk menghitung kebutuhan dapur berdasarkan tanggal
export async function getKitchenNeedsByDate(date: string): Promise<any> {
  // Ambil semua reservasi pada tanggal tersebut
  const reservations = await getReservationsByDate(date)

  // Ambil semua item pesanan untuk reservasi tersebut
  const reservasiIds = reservations.map((res) => res.id)

  if (reservasiIds.length === 0) {
    return {
      makanan: [],
      minuman: [],
    }
  }

  const { data: orderItems, error: orderItemsError } = await supabase
    .from("item_pesanan")
    .select(`
      *,
      menu:menu_id(*)
    `)
    .in("reservasi_id", reservasiIds)

  if (orderItemsError) {
    console.error("Error fetching order items for kitchen needs:", orderItemsError)
    return {
      makanan: [],
      minuman: [],
    }
  }

  // Hitung kebutuhan bahan berdasarkan resep
  const bahanCounts: Record<number, { bahan: BahanResep; jumlah: number }> = {}

  for (const item of orderItems || []) {
    // Ambil resep untuk menu ini
    const resep = await getResepByMenuId(item.menu_id)

    for (const resepItem of resep) {
      const bahanId = resepItem.bahan_id
      const jumlahPerPorsi = resepItem.jumlah
      const totalJumlah = jumlahPerPorsi * item.jumlah

      if (bahanCounts[bahanId]) {
        bahanCounts[bahanId].jumlah += totalJumlah
      } else {
        bahanCounts[bahanId] = {
          bahan: resepItem.bahan,
          jumlah: totalJumlah,
        }
      }
    }
  }

  // Pisahkan bahan makanan dan minuman
  const makanan = Object.values(bahanCounts)
    .filter((item) => item.bahan.kategori === "makanan" || item.bahan.kategori === "bumbu")
    .sort((a, b) => a.bahan.nama.localeCompare(b.bahan.nama))

  const minuman = Object.values(bahanCounts)
    .filter((item) => item.bahan.kategori === "minuman")
    .sort((a, b) => a.bahan.nama.localeCompare(b.bahan.nama))

  return {
    makanan,
    minuman,
  }
}

