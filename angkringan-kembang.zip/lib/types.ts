export interface Admin {
  id: number
  nama: string
  username: string
  aktif: boolean
  created_at: string
}

export interface KategoriMenu {
  id: number
  nama: string
  created_at: string
}

export interface MenuItem {
  id: number
  nama: string
  kategori_id: number
  harga: number
  deskripsi?: string
  tersedia: boolean
  is_paket: boolean
  created_at: string
  updated_at: string
  kategori?: KategoriMenu
}

export interface KategoriBahan {
  id: number
  nama: string
  created_at: string
}

export interface Bahan {
  id: number
  nama: string
  kategori_id: number
  satuan: string
  stok: number
  created_at: string
  updated_at: string
  kategori?: KategoriBahan
}

export interface Resep {
  id: number
  menu_id: number
  bahan_id: number
  jumlah: number
  created_at: string
  bahan?: Bahan
  menu?: MenuItem
}

export interface Meja {
  id: number
  nomor: string
  kapasitas: number
  tersedia: boolean
  created_at: string
}

export interface FasilitasTambahan {
  id: number
  nama: string
  biaya: number
  deskripsi?: string
  created_at: string
}

export type StatusReservasi = "pending" | "confirmed" | "cancelled" | "completed"
export type StatusPembayaran = "belum_bayar" | "dp" | "lunas"
export type MetodePembayaran = "cash" | "transfer" | "qris"

export interface Reservasi {
  id: number
  nama_pemesan: string
  nomor_telepon: string
  email?: string
  jumlah_orang: number
  tanggal_reservasi: string
  waktu_reservasi: string
  meja_id?: number
  status: StatusReservasi
  total_harga: number
  status_pembayaran: StatusPembayaran
  jumlah_pembayaran: number
  metode_pembayaran?: MetodePembayaran
  catatan?: string
  admin_id?: number
  created_at: string
  updated_at: string
  meja?: Meja
  admin?: Admin
}

export interface ItemPesanan {
  id: number
  reservasi_id: number
  menu_id: number
  jumlah: number
  harga_satuan: number
  subtotal: number
  catatan?: string
  created_at: string
  menu?: MenuItem
}

export interface ReservasiFasilitas {
  id: number
  reservasi_id: number
  fasilitas_id: number
  biaya: number
  created_at: string
  fasilitas?: FasilitasTambahan
}

