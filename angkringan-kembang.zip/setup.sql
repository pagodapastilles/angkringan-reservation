-- Create enum types
CREATE TYPE status_reservasi AS ENUM ('pending', 'confirmed', 'cancelled', 'completed');
CREATE TYPE status_pembayaran AS ENUM ('belum_bayar', 'dp', 'lunas');
CREATE TYPE metode_pembayaran AS ENUM ('cash', 'transfer', 'qris');

-- Create kategori_menu table
CREATE TABLE IF NOT EXISTS kategori_menu (
    id SERIAL PRIMARY KEY,
    nama VARCHAR(50) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create menu table
CREATE TABLE IF NOT EXISTS menu (
    id SERIAL PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    kategori_id INTEGER REFERENCES kategori_menu(id),
    harga INTEGER NOT NULL DEFAULT 0,
    deskripsi TEXT,
    tersedia BOOLEAN DEFAULT true,
    is_paket BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create kategori_bahan table
CREATE TABLE IF NOT EXISTS kategori_bahan (
    id SERIAL PRIMARY KEY,
    nama VARCHAR(50) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create bahan table
CREATE TABLE IF NOT EXISTS bahan (
    id SERIAL PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    kategori_id INTEGER REFERENCES kategori_bahan(id),
    satuan VARCHAR(20) NOT NULL,
    stok DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create resep table
CREATE TABLE IF NOT EXISTS resep (
    id SERIAL PRIMARY KEY,
    menu_id INTEGER REFERENCES menu(id) ON DELETE CASCADE,
    bahan_id INTEGER REFERENCES bahan(id),
    jumlah DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create meja table
CREATE TABLE IF NOT EXISTS meja (
    id SERIAL PRIMARY KEY,
    nomor VARCHAR(10) NOT NULL UNIQUE,
    kapasitas INTEGER NOT NULL DEFAULT 1,
    tersedia BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create fasilitas_tambahan table
CREATE TABLE IF NOT EXISTS fasilitas_tambahan (
    id SERIAL PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    biaya INTEGER NOT NULL DEFAULT 0,
    deskripsi TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create admin table
CREATE TABLE IF NOT EXISTS admin (
    id SERIAL PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    aktif BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create reservasi table
CREATE TABLE IF NOT EXISTS reservasi (
    id SERIAL PRIMARY KEY,
    nama_pemesan VARCHAR(100) NOT NULL,
    nomor_telepon VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    jumlah_orang INTEGER NOT NULL DEFAULT 1,
    tanggal_reservasi DATE NOT NULL,
    waktu_reservasi TIME NOT NULL,
    meja_id INTEGER REFERENCES meja(id),
    status status_reservasi DEFAULT 'pending',
    total_harga INTEGER NOT NULL DEFAULT 0,
    status_pembayaran status_pembayaran DEFAULT 'belum_bayar',
    jumlah_pembayaran INTEGER DEFAULT 0,
    metode_pembayaran metode_pembayaran,
    catatan TEXT,
    admin_id INTEGER REFERENCES admin(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create item_pesanan table
CREATE TABLE IF NOT EXISTS item_pesanan (
    id SERIAL PRIMARY KEY,
    reservasi_id INTEGER REFERENCES reservasi(id) ON DELETE CASCADE,
    menu_id INTEGER REFERENCES menu(id),
    jumlah INTEGER NOT NULL DEFAULT 1,
    harga_satuan INTEGER NOT NULL DEFAULT 0,
    subtotal INTEGER NOT NULL DEFAULT 0,
    catatan TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create reservasi_fasilitas table
CREATE TABLE IF NOT EXISTS reservasi_fasilitas (
    id SERIAL PRIMARY KEY,
    reservasi_id INTEGER REFERENCES reservasi(id) ON DELETE CASCADE,
    fasilitas_id INTEGER REFERENCES fasilitas_tambahan(id),
    biaya INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Insert default kategori_menu
INSERT INTO kategori_menu (nama) VALUES 
('Makanan'),
('Minuman'),
('Camilan')
ON CONFLICT DO NOTHING;

-- Insert default kategori_bahan
INSERT INTO kategori_bahan (nama) VALUES 
('Makanan'),
('Minuman'),
('Bumbu')
ON CONFLICT DO NOTHING;

-- Insert default admin
INSERT INTO admin (nama, username, password) VALUES 
('Administrator', 'admin', 'admin123')
ON CONFLICT DO NOTHING;

-- Add RLS policies
ALTER TABLE menu ENABLE ROW LEVEL SECURITY;
ALTER TABLE bahan ENABLE ROW LEVEL SECURITY;
ALTER TABLE resep ENABLE ROW LEVEL SECURITY;
ALTER TABLE meja ENABLE ROW LEVEL SECURITY;
ALTER TABLE fasilitas_tambahan ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservasi ENABLE ROW LEVEL SECURITY;
ALTER TABLE item_pesanan ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservasi_fasilitas ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for all users" ON menu FOR SELECT USING (true);
CREATE POLICY "Enable read access for all users" ON bahan FOR SELECT USING (true);
CREATE POLICY "Enable read access for all users" ON resep FOR SELECT USING (true);
CREATE POLICY "Enable read access for all users" ON meja FOR SELECT USING (true);
CREATE POLICY "Enable read access for all users" ON fasilitas_tambahan FOR SELECT USING (true);
CREATE POLICY "Enable read access for all users" ON reservasi FOR SELECT USING (true);
CREATE POLICY "Enable read access for all users" ON item_pesanan FOR SELECT USING (true);
CREATE POLICY "Enable read access for all users" ON reservasi_fasilitas FOR SELECT USING (true);

-- Enable insert/update/delete for authenticated users
CREATE POLICY "Enable full access for authenticated users" ON menu FOR ALL USING (true);
CREATE POLICY "Enable full access for authenticated users" ON bahan FOR ALL USING (true);
CREATE POLICY "Enable full access for authenticated users" ON resep FOR ALL USING (true);
CREATE POLICY "Enable full access for authenticated users" ON meja FOR ALL USING (true);
CREATE POLICY "Enable full access for authenticated users" ON fasilitas_tambahan FOR ALL USING (true);
CREATE POLICY "Enable full access for authenticated users" ON reservasi FOR ALL USING (true);
CREATE POLICY "Enable full access for authenticated users" ON item_pesanan FOR ALL USING (true);
CREATE POLICY "Enable full access for authenticated users" ON reservasi_fasilitas FOR ALL USING (true);

